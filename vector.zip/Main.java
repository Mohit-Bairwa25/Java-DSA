import java.util.*;
public class Main {
	public static void main(String[] args) {
        Enumeration e;
        Vector months = new Vector(3);
        System.out.println("Initial size: "+ months.size());
        System.out.println("Initial capacity: " + months.capacity());
        
        months.add("Jan");
        months.add("Feb");
        months.add("March");
        months.add("April");
        months.add("May");
        System.out.println(months);
        System.out.println("size: "+ months.size());
        System.out.println("capacity: " + months.capacity());
        
        months.add("June");
        months.add("July");
        months.add("Aug");
        months.add("Sept");
        System.out.println(months);
        System.out.println("size: "+ months.size());
        System.out.println("capacity: " + months.capacity());
        
        months.add("Oct");
        months.add("Nov");
        months.add("Dec");
        System.out.println(months);
        System.out.println("size: "+ months.size());
        System.out.println("capacity: " + months.capacity());
        
        months.insertElementAt("Ravi",2);
        System.out.println(months);
        System.out.println("size: "+ months.size());
        System.out.println("capacity: " + months.capacity());
        
        months.removeElement("Ravi");
        System.out.println("After Removing Ravi"+months);
        months.removeElementAt(1);
        System.out.println("After Removing First Indx"+months);
        months.removeAllElements();
        System.out.println("After Removing All "+months);
	}
}
