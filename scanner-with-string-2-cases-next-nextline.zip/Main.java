/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*; // Java is Case Sensitive language here J of java will be small
public class Main
{
  public static void main (String[]args)
  {
// Case 1 : s.next(); It shows 1st word of Sentence
    Scanner s = new Scanner (System.in);
    String x = s.next ();
      System.out.println (x);
// Case 2 : s.nextLine(); It shows full Sentence   
    Scanner t = new Scanner (System.in);
    String y = t.nextLine ();
      System.out.println (y);
  }
}

