/*  Manual :- Explicit Typecasting--> Write Code for it
    Narrowing Data Type
    Double > Float > Long > Int > Char > Short
    
*/
public class Main
{
  public static void main (String[]args)
  {
    double d = 11111.7777777777777; // double NOT Double # Case Sesitive
    float z =  (float) d;
    long a = (long) z;
    int b =(int) a;
    char c =(char)b;
    System.out.println (z);
    System.out.println (a);
    System.out.println (b);
    System.out.println (c);
// We can see data is being lost at its being Narrowing Down
  }
}
