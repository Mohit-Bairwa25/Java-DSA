import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc= new Scanner(System.in);
    int a=sc.nextInt();
    int bill=0;
    if(a<=100)
    {
      bill=15*a;
    System.out.println(bill);
    }
    else if(100<a && a<=200)
    {
      bill=100*15+14*(a-100);
      System.out.println(bill);
    }
    else
    {
      bill=100*15+100*14+12*(a-200);
      System.out.println(bill);
        
    }
  }
}
