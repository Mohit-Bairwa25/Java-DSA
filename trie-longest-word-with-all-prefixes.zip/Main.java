/* Longest Word with all Prefixes

Find the Longest String in words such that every prefix of
it is also in words.

words =["a","banana","app","appl","ap","apply","apple"]

ans = "apple"

apple & apply are similar but according to lexicographic order
(ascending) apple is smaller
*/

public class Main {
    static class Node {
        Node[] children;
        boolean eow;

        public Node() {
            children = new Node[26];
            eow = false;
        }
    }

    static Node root = new Node();

    public static void insert(String word) {
        Node curr = root;
        for (int i = 0; i < word.length(); i++) { // O(L)
            int idx = word.charAt(i) - 'a';
            if (curr.children[idx] == null) {
                // add new Node
                curr.children[idx] = new Node();
            }
            if (i == word.length() - 1) {
                curr.children[idx].eow = true;
            }
            curr = curr.children[idx];
        }
    }

    public static String ans = "";

    public static void longestWord(Node root, StringBuilder temp) {
        for (int i = 0; i < 26; i++) {
            if (root.children[i] != null && root.children[i].eow) {
                temp.append((char) (i + 'a'));
                if (temp.length() > ans.length()) {
                    ans = temp.toString();
                }
                longestWord(root.children[i], temp);
                temp.deleteCharAt(temp.length() - 1);
            }
        }
    }

    public static void main(String[] args) {
        String[] words = { "a", "banana", "app", "appl", "ap", "apply", "apple" };
        for (String word : words) {
            insert(word);
        }
        longestWord(root, new StringBuilder());
        System.out.println(ans);
    }
}