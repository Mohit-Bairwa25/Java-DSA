/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
  public static void main (String[]args)
  {
    /* char stores only single values like 1,3,t,x etc*/
    char u = 'a';		// Always store values in Single Quotes ''
      System.out.println (u);
    char v = '6';
      System.out.println (v);
/*Boolean is used to store true or false statement */
    boolean b = true;		// t of true should be small    
      System.out.println (b);
  }
}

