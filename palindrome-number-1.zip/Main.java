import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    int num, t, s, rem;
    Scanner sc = new Scanner (System.in);
      System.out.print ("Enter Any Number : ");
      num = sc.nextInt ();
      t = num;
    for (s = 0; num > 0; num /= 10)
      {
	rem = num % 10;
	s = (s * 10) + rem;
      }
    if (s == t)
      System.out.println (t + " is a Palindrome Number ");
    else
      System.out.println (t + " is not a Palindrome Number ");

  }
}

