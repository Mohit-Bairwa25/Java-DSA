public class Main{
    public static void main (String[]args){
        byte a = 123; // 8-bit integer (no suffix needed)
        System.out.println(a);
        
        short b = 12345; // 16-bit integer (no suffix needed)
        System.out.println(b);
        
        int c = 123456789; // 32-bit integer (no suffix needed)
        System.out.println(c);
        
        long d = 1234567891011121314L; // 64-bit long (suffix 'L' indicates long)
        // Because System By Default treat it as a Integer Value
        System.out.println(d);
        
        Float f=3.12345678910f; //float occupies 32 bits (4 bytes), (suffix 'f' indicates float)
        /*Always use small f at the end of the float value
        Because System by Default consider any decimal value as Double datatype*/
        System.out.println(f);
        
        /*double is used to store larger decimal values
        float for smaller values*/
        double e=20.1234567891011121314151617181920; //double occupies 64 bits (8 bytes).
        System.out.println(e);
  }
}


