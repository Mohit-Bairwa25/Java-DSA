//Write a program to toggle a bit a position = “pos” in a number “n” in java

public class Main {
    public static int toggleBit(int n, int pos) {
        // Shift 1 to the left by 'pos' to create a mask
        int mask = 1 << pos;
        
        // Toggle the bit at the specified position using XOR operator
        return n ^ mask;
    }
    
    public static void main(String[] args) {
        int n = 10; // Example number
        int pos = 2; // Example position
        
        // Print the original number
        System.out.println("Original number: " + n);
        
        // Toggle the bit at the specified position
        n = toggleBit(n, pos);
        
        // Print the number after toggling the bit
        System.out.println("Number after toggling bit at position " + pos + ": " + n);
    }
}

/* 
1.Original number: Initially, we have n = 10 (in binary: 1010).
This is our starting number.

2. Creating the mask: We shift the bit 1 left by the position
pos = 2, so mask = 1 << 2, which gives us mask = 100 in binary.

3.Toggle the bit: We perform XOR between the original number n
and the mask. XOR toggles a bit to 1 if it's 0 and vice versa.
So, in this case, the bit at position 2 in n is 0, and the
corresponding bit in the mask is 1, so the result of XOR will be 1.
The other bits remain unchanged. So, the new number after toggling
the bit becomes 14 (in binary: 1110).

Let's simulate it:

Original number n = 10 (binary: 1010)
Mask mask = 100
Performing XOR operation:
n: 1010
mask: 0100
Result: 1110 (which is 14 in decimal)
*/
