import java.util.Scanner;	// S of the Scanner should be CAPITAL & ; Semi colen is must
public class Main {
  public static void main (String[]args) {
    // For Integer value
    Scanner sc = new Scanner (System.in);
      System.out.print ("Enter a Integer Value : ");
    int x = sc.nextInt ();  // Int I should be CAPITAL
      System.out.println("Entered Integer Value is : " + x);
    // For Floatvalue
    Scanner sm = new Scanner (System.in);
      System.out.print ("Enter a Float Value : ");
    float y = sm.nextFloat ();	// Float F should be CAPITAL
      System.out.println("Entered Float Value is : " + y);
      // FOR String
    Scanner so = new Scanner (System.in);
      System.out.print ("Enter a String : ");
    String z = so.next();	 
    /* No need to write string as above cases 
     you can use nextLine to show result in nextLine
     String does not print whole sentence
     it just print 1st word of the sentence*/
      System.out.println("Entered String is : " + z);
  }
}



