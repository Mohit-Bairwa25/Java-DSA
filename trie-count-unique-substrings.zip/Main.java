/*Given a String of length n of lowercase alphabet characters, we
need to count total number of distinct substrings of this string.

str = "ababa"
ans = 10

Hint: Can be solved by 2 Cases
All prefix of all suffix
All suffix of all prefix

suffix
ababa --> a, ab, aba, abab, ababa
baba --> b, ba, bab, baba
aba --> a, ab, aba
ba --> b, ba
a --> a
" " --> " "

Trie data structure is useful here because it only stores unique elements
Total nodes of trie = count of prefix
*/

import java.util.*;

public class Main {

    static class Node {
        Node[] children;
        boolean eow; // end of word

        public Node() {
            children = new Node[26]; // a to z
            eow = false;
        }
    }

    static Node root = new Node();
    static List<String> uniqueSubstrings = new ArrayList<>();

    public static void insert(String word) {
        Node curr = root;
        for (int i = 0; i < word.length(); i++) { // O(L)
            int idx = word.charAt(i) - 'a';
            if (curr.children[idx] == null) {
                // add new node
                curr.children[idx] = new Node();
            }
            curr = curr.children[idx];
        }
        if (!curr.eow) { // if the substring is not already in the trie
            curr.eow = true; // mark the end of word
            uniqueSubstrings.add(word);
        }
    }

    public static int countNode(Node root) {
        int count = 1; // Count the root node initially
        if (root == null) {
            return 0;
        }
        for (int i = 0; i < 26; i++) {
            if (root.children[i] != null) {
                count += countNode(root.children[i]);
            }
        }
        return count;
    }

    public static void main(String[] args) {
        String str = "ababa";
        for (int i = 0; i <= str.length(); i++) {
            for (int j = i + 1; j <= str.length(); j++) {
                String substring = str.substring(i, j);
                insert(substring);
            }
        }

        System.out.println("Unique Substrings: " + uniqueSubstrings);
        System.out.println("Count of Unique Substrings (including empty node): " + countNode(root));
    }
}