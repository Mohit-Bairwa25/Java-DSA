/* These escape sequences are special characters that allow us to signal an
alternative interpretation of a series of characters.
These sequences are often used to control the output of text in Java programs
*/
public class Main{
  public static void main (String[]args){
    System.out.print ("Chacha Bhatija.\n");  // \n is used for next line inside "\n"
    System.out.print ("Welcome to AccioJob\t"); // \t is used for tabspace inside "\t"
    System.out.print ("Teacher is Uday");
    System.out.println ("Student is Mohit");
    //when print ln is used the compiler show next result in next line
    System.out.println ("Student is Karan");
    System.out.println("Tota,\\b Maina!");
    /*
    \\b: Denotes a backspace character. It moves the cursor one character back, 
     either with or without deleting the character (depending on the compiler).
    */ 
    System.out.println("Mama,\rBhanja!");
    /*
    \r: Indicates a carriage return character.
    It moves the cursor to the beginning of the current line.
    */
  }
}




