public class Main
{
  public static void main (String[]args)
  {
// Pre Increment Operator
    int a=5;
        System.out.println ("a : "+a);
        System.out.println("Ater Using Pre Increment Operator");
    int b=++a;
        System.out.println ("a : "+a);
// Here Value of a is increaed by increment operator in line 6
        System.out.println ("b : "+b);
// Here Value of a is icrement and the assinged to b
        
        System.out.println();
// Post Increment Operator
    int c=5;
        System.out.println ("c : "+c);
        System.out.println("After Using Post Increment Operator");
    int d=c++;
        System.out.println ("c : "+c);
//Here value c of is increased by increment Operator in line 18
        System.out.println ("d : "+d);
// Here d is picking value of c from line 15 c
        System.out.println();

// Pre Decrement Operator
    int e=5;
        System.out.println ("e : "+e);
        System.out.println("After Using Pre Decrement Operator");
    int f=--e;
        System.out.println ("e : "+e);
        System.out.println ("f : "+f);
        System.out.println();

// Post Decrement Operator
    int g=5;
        System.out.println ("g : "+g);
        System.out.println("After Using Post Decrement Operator");
    int h=g--;
        System.out.println ("g : "+g);
        System.out.println ("h : "+h);
  }
}


