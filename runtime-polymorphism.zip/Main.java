/* Runtime Polymorphism : Runtime polymorphism is also
known as dynamic polymorphism. Function overriding is an
example of runtime polymorphism. Function overriding means
when the child class contains the method which is already
present in the parent class. Hence, the child class overrides
the method of the parent class. In case of function overriding,
parent and child classes both contain the same function with a
different definition. The call to the function is determined at
runtime is known as runtime polymorphism. */

class Shape {
   public void area() {
       System.out.println("Displays Area of Shape");
   }
}
class Triangle extends Shape {
   public void area(int h, int b) {
       System.out.println((0.5)*b*h);
   }  
}
class Circle extends Shape {
   public void area(int r) {
       System.out.println((3.14)*r*r);
   }  
}

public class Main {
    public static void main (String [] args) {
        Triangle t=new Triangle();
        t.area();
        t.area(10,5);
        
        Circle c= new Circle();
        c.area();
        c.area(100);
    }
}
