import java.util.*;
import java.io.*;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc =new Scanner(System.in);
    int n = sc.nextInt();
    int [] arr= new int[n];
    int k = sc.nextInt();
    for(int i=0;i<n;i++)
    {
        arr[i] = sc.nextInt();
    }
    int par_score = arr[k-1];
    int count = 0;
    for(int i=0;i<n;i++)
    {
        if (arr[i]>=par_score && arr[i]>0)
        count++;
    }
    System.out.print(count);
  }
}
