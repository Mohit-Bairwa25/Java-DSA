
public class Main
{
  public static void main (String[]args)
  {
    
    double num=20.786;
 System.out.println("Saved value is - " + num);
 /* You can print Together ny using + and entering the text in "TEXT HERE"*/
  }
}
