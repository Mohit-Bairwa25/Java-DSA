import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    /*
       1
       01
       101
       0101
       10101
       Here we can See Pattern 
       1 comes at cordinates which has sum divisible by 2
     */
    Scanner sc = new Scanner (System.in);
    int n = sc.nextInt ();
    int o = 1;
    // outer loop
    for (int i = 1; i <= n; i++)
      {
	// inner loop spaces
	for (int j = 1; j <= i; j++)
	  {
	      if((i+j)%2==0)      // Even
	    System.out.print (1);
	    else                  // Odd
	    System.out.print (0);
	    
	  }

	System.out.println ();
      }
  }
}
