/* Find the nth node from the end & remove it.
For Example LL = [my, name, is, shradha, kharpa ]
remove 2nd node from last then remove it,the 2nd last
node of LL is shardha, so the output shouuld be
my name is kharpa
*/

import java.util.LinkedList;

public class Main {
    public ListNode removeNthFromEnd(ListNode head, int n) {
        if (head == null || (head.next == null && n == 1)) {
            return null; // Empty list or list with only one node and n == 1
        }
        
        ListNode dummy = new ListNode("dummy");
        dummy.next = head;
        
        ListNode first = dummy;
        ListNode second = dummy;
        
        // Move the second pointer n nodes ahead
        for (int i = 1; i <= n + 1; i++) {
            second = second.next;
            if (second == null) {
                // The list has fewer than n + 1 nodes
                return head;
            }
        }
        
        // Move both pointers until the second pointer reaches the end
        while (second != null) {
            first = first.next;
            second = second.next;
        }
        
        // Remove the nth node from the end
        first.next = first.next.next;
        
        return dummy.next;
    }

    public static void main(String[] args) {
        Main solution = new Main();
        LinkedList<String> list = new LinkedList<>();
        
        list.addFirst("my");
        list.addFirst("name");
        list.addFirst("is");
        list.addFirst("shradha");
        list.addFirst("kharpa");
        
        // Convert LinkedList to ListNode
        ListNode head = null;
        for (String s : list) {
            ListNode newNode = new ListNode(s);
            newNode.next = head;
            head = newNode;
        }
        
        // Remove the 2nd node from the end
        int n = 2;
        ListNode result = solution.removeNthFromEnd(head, n);
        
        // Print the result
        while (result != null) {
            System.out.print(result.val + " ");
            result = result.next;
        }
    }
}

class ListNode {
    String val;
    ListNode next;

    ListNode(String x) {
        val = x;
    }
}