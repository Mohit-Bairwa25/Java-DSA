import java.util.*;
// Print The Position of the Array in Matrix
public class Main
{
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
	    System.out.print("Enter Rows : ");
	    int m=sc.nextInt();
	    System.out.print("Enter Column : ");
	    int n=sc.nextInt();
	    System.out.println("Enter Array : ");
	    int[][] arr= new int[m][n];
	    
	    // Input
	    for(int i=0;i<m;i++){
	        for(int j=0;j<n;j++ ){
	            arr[i][j]=sc.nextInt();
	        }
	    }
	    
	    System.out.print("Enter the Array Element to Find : ");
	    int o=sc.nextInt();
	    
	    // Output
	     for(int i=0;i<m;i++){
	        for(int j=0;j<n;j++ ){
	            if(arr[i][j]==o)
	            System.out.println("Element fount at : "+i+"\t"+j);
	            else
	            System.out.println("Element NOT found in Array");
	        }

	    }
		
	}
}

