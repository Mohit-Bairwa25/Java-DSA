import java.util.*;

public class Main {
    public static void main(String args[]) {
      Scanner sc = new Scanner(System.in);
      int n = sc.nextInt();
      int m = sc.nextInt();
      
      /*Suppose a Matrix of 4*4
        01 02 03 04
        05 06 07 08
        09 10 11 12
        13 14 15 16*/
        
        int matrix[][] = new int[n][m];
        for(int i=0; i<n; i++) {
            for(int j=0; j<m; j++) {
               matrix[i][j] = sc.nextInt();
            }
        }
      
      System.out.println("The Spiral Order Matrix is : ");
      int rowStart = 0;
      int rowEnd = n-1;
      int colStart = 0;
      int colEnd = m-1;
      
        //To print spiral order matrix
        while(rowStart <= rowEnd && colStart <= colEnd) {
            //1
            for(int col=colStart; col<=colEnd; col++) {
              System.out.print(matrix[rowStart][col] + " ");
            }
            /*01 02 03 04
              06 07*/
            rowStart++;
            /*(i,j=2,4)
              (i,j=3,3)*/
          
            //2
            for(int row=rowStart; row<=rowEnd; row++) {
                System.out.print(matrix[row][colEnd] +" ");
            }
            /*08 12 16
              11*/
            colEnd--;
            /*(i,j=4,3)
              (i,j=3,2)*/
          
            //3
            for(int col=colEnd; col>=colStart; col--) {
              System.out.print(matrix[rowEnd][col] + " ");
            }
            /*15 14 13
              10*/
            rowEnd--;
            /*(i,j=3,1)*/
          
            //4
            for(int row=rowEnd; row>=rowStart; row--) {
                System.out.print(matrix[row][colStart] + " ");
            }
            /*09 05*/
            colStart++;
            /*(i,j=2,2)*/
          
            System.out.println();
        }
    }
}