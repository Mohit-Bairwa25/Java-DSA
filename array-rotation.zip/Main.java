import java.util.Scanner;
/* 3 4 5 k=0
   5 3 4 k=1
   4 5 3 k=2
   3 4 5 k=3
   
k=13 n=8
so final work 13-8=5*/
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int k=sc.nextInt();
    int q=sc.nextInt();
    int []arr = new int[n];
    for(int i=0;i<n;i++)
    {
        arr[i]=sc.nextInt();
    }
    int [] rotated=new int[n];
    k=k%n;
    for(int i=0;i<n;i++)
    {
        rotated[(i+k)%n]=arr[i];
    }
    for(int i=0;i<q;i++)
    {
        int index=sc.nextInt();
        System.out.println(rotated[index]);
    }
  }
}

