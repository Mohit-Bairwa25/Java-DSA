 /* Inheritance :- Ek Class Ki Properties Koi Dusri Class Lena Chaahti Hai

*/
// Multilevel Inheritance
class Shape { // Base/Parent Class
    String color;
    public void area () {
        System.out.println("Display Area");
    }
}

class Triangle extends Shape { // Child Class
    public void area1 (int l, int h) {
       System.out.println(l*h*0.5);
        
    } 
}

class EquilateralTriangle extends Triangle{
    public void perimeter (int l) {
       System.out.println(3*l);
   }
}

public class Main{
	public static void main(String[] args) {
        Shape s1= new Shape();
		s1.area();
		
		Triangle t1= new Triangle();
		t1.area1(10,5);
		t1.area();
		
		EquilateralTriangle e1= new EquilateralTriangle();
		e1.perimeter(30);
		e1.area1(10,50);
		e1.area();
		
	}
}


