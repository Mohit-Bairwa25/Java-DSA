/*  Typecasting :- Converting one Data Type into another Data Type
    Two Types  1 Implicit Typecasting 2 Explicit Typecasting
   
    Automatic :- Implicit Typecasting--> Compiler
    Compatibility :- Cannot Convert Integr --> X Char,Boolean
    Wideing Data Type
    Higher Data Type --> Smaller Data Type 
    Short > Int > Long > Float >  Double
 */
public class Main
{
  public static void main (String[]args)
  {
    int c=10;
    long y=c;
    float z=y;
    System.out.println (z);
  }
}



