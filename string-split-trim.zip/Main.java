import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    String s = "               Hello World                 ";
// The trim() method removes whitespace from both ends of a string.
        s = s.trim();
		System.out.println(s);
		
/*The split() method splits a string into an array of substrings.
The split() method returns the new array.
The split() method does not change the original string.
If (" ") is used as separator, the string is split between words.*/

        String [] words = s.split("[^a-zA-Z]+");
        System.out.println(words);
        for (String word : words) {
            System.out.println(word);
        }
	}
}
