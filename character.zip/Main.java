/*Charchter ,char is used to store single data type a,s,f,3,%,<,4
its should be store in single quotes 'a'   '@'   '4'  etc correct way
"a"   "ab "   'ab'   Wrong way
sc.nextchar() XXX This does not Exsist in Java*/
import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    Scanner c=new Scanner(System.in);
    System.out.print ("Entered Charchter Value is : ");
    char z=c.next().charAt(0); /* Here 0 means it would pick up 1st Charchter of the String
    the input uday shows output u*/
    System.out.println ("Entered Value is : "+ z);
  }
}


