public class Main{
// Print all SubSequences of a String
    public static void subSequences (String str,int idx,String newString) {
        if(idx==str.length()){
            System.out.println(newString);
            return;
        }
        char currChar=str.charAt(idx);
        
        //To be
        subSequences(str,idx+1,newString+currChar);
        
        // Not to be
        subSequences(str,idx+1,newString);
    }
	public static void main(String[] args) {
	    String str="abc";
	    subSequences(str,0,"");
	}
}
//TC=O(2^n )
