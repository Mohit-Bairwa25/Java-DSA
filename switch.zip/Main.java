import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    System.out.println ("How to make a Tea");
    Scanner s= new Scanner(System.in);
    int var= s.nextInt();
    switch (var) 
/*When Entered a value from follwing case it wil print all the values below it*/ 
    {
        default :System.out.println ("Entered Value is Not Defined");
         case 1 :System.out.println ("Put a cup of water in Empty Kettle");
         case 2 :System.out.println ("Turn on gas and keep Kettle on it");
         case 3 :System.out.println ("Add 2 Spoon Tea");
         case 4 :System.out.println ("Add 15gram of Crushed Ginger");
         case 5 :System.out.println ("Boil the water on Medium Flame for 4 Minutes");
         case 6 :System.out.println ("Add 2 Cup of Milk");
         case 7 :System.out.println ("Add 2 Spoon Sugar");
         case 8 :System.out.println ("Boil the water on High Flame for 10 Minutes");
         case 9 :System.out.println ("Filter the solution and Serve it");
        
    } 
    
  }
}


