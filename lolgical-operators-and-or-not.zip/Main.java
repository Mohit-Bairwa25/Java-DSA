import java.util.Scanner;
public class Main {
    public static void main (String[]args) {
        System.out.println ("Starting of the Program");
        Scanner s= new Scanner(System.in);
        int a= s.nextInt();
        // Change the Operators to check
        if(a>100 && a<200) {
            /* Logical Operators AND && , OR || , NOT !=  */
            System.out.println("Input Value has a Range of 100-200");
        }
        System.out.println("Input Value  NOT has a Range of 100-200");
        System.out.println ("Ending of the Program");
    }
}


