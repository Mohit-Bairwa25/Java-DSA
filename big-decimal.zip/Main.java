/*

                        BigDecimal in Java
we know that we should use float and double primitive types for decimal
numbers. But there is one problem with these primitive types float and
double that these types should never be used for precise value, such as
currency.

*/
import java.math.BigDecimal;
public class Main {
    public static void main(String[] args) {
        
        System.out.println("----- financial calculation with double or float ---- ➖➖➖ -----");
        double d1 = 374.56;
        double d2 = 374.26; I
        // result would be d1 - d2 = 0.30000000000001137
        System.out.println( "d1 - d2 = " + ( d1 - d2 ));
        // result would be bd1 - bd2 = 0.30
        
        System.out.println("-------- financial calculation with BigDecimal- ------");
        BigDecimal bigDecimal1 = new BigDecimal("374.56") ;
        BigDecimal bigDecimal2 = new BigDecimal("374.26");
        System.out.println("bdl - bd2 = " + bigDecimall.subtract(bigDecimal2));
        
        System.out.println("➖➖➖➖➖➖➖➖ ---- BigDecimal Constructors-➖➖➖➖ -");
        // Contructor with double value
        BigDecimal bigDecimal3 = new BigDecimal(23.12);
        // result would be 23.120000000000000994759830064140260219573974609375
        System.out.println(bigDecimal3.toString());
        // Contructor with String value
        BigDecimal bigDecimal4 = new BigDecimal("23.12") ;
        // result would be 23.12
        System.out.println("" + bigDecimal4.toString());
    }
}