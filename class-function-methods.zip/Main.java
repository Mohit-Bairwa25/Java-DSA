class Pen { 
// Class Name Start with CAPITAL Letter By Convention
    String color;
    String type; //ballpoint; gel
    public void write() {
        System.out.println("writing something") ;
    }
    
    public void printColor() {
        // Method Name Start with small Letter By Convention
        System.out.println(this.color);
    }
    
    public void printType() {
        // Method Name Start with small Letter By Convention
        System.out.println(this.type);
    }
}

public class Main {
    public static void main (String args [] ) {
        Pen pen1 = new Pen();
        pen1.color = "blue";
        pen1.type = "gel";
        pen1.write();
        
        Pen pen2=new Pen();
        pen2.color="black";
        pen2.type="ballpoint";
        
        pen1.printColor();
        pen2.printColor();
        
        pen1.printType();
        pen2.printType();
    }
}




