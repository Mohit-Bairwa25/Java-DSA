public class Main
{
	public static void main(String[] args) {
		//Compare
		String name1="Tony";
		String name2="Tony";
		
		//1 s1>s2 : +ve value
		//2 s1==s2 :0 value
		//3 s1<s3 :-ve value
		// A<B<C<D..........X<Y<Z
		// Sony<Tony
		
		if(name1.compareTo(name2)==0){
		    System.out.println("Equal String");
		}
		else{
		    System.out.println("NOT Equal String");
		}
		
		// This Methods Fails Few Test Cases
		
		if(name1==name2){
		    System.out.println("Equal String");
		}
		else{
		    System.out.println("NOT Equal String");
		}
		
		// String Builder Concept
		
		if(new String("Tony")==new String("Tony")){
		    System.out.println("Equal String");
		}
		else{
		    System.out.println("NOT Equal String");
		}
	}
}
