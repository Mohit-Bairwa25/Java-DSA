import java.util.Scanner;
public class Main{
  public static void main (String[]args){
    Scanner sc = new Scanner (System.in);
      int m = sc.nextInt ();
      int n = sc.nextInt ();
      int o = sc.nextInt ();	// Solve Close Argument
      // For Loop
        for (int i = 0; i < m; i++){
	      System.out.println (i);
    	}
          // While Loop
          int j = 0;
          while (j < n){
	        j++;
	        System.out.println (j);
	      }
	          // Do While
              int k = 0;
              do{
                  k++;
	              System.out.println (k);
	            }while (k < o);		// Remember ; Here
    }
  }

