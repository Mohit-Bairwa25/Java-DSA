import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc=new Scanner(System.in);
    long n=sc.nextInt();
    long x=0;
    long y=1;
    long z=0;
    for(long i=2;i<=n;i++)
    {
      z=x+y;
      x=y;
      y=z;
    }
    System.out.println(z);
    long a=z%10;
    long b=(z%100-a)/10;
    System.out.println(a+"\n"+b);
    
  }
}
