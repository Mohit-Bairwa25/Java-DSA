public class Main
{
  public static void main (String[]args)
  {
    for (int i = 1; i <= 10; i++)	//Initialisation,Condition & Updation
      {
	System.out.println ("2x" + i + "=" + i * 2);	//Task
      }

  }
}
