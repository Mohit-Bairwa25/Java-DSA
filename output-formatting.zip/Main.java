import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        String s1="Java";
        int x=7;
/* Here we -15 between % and s is space between string and int
    15 between % and s is space before string and int
    
    01,02,03 between % and d show number digit in int
            
*/
                
        System.out.printf("%-15s%d\n", s1, x);
        System.out.printf("%-10s%d\n", s1, x);
        System.out.printf("%-5s%d\n", s1, x);
        System.out.printf("%s%d\n", s1, x);
        System.out.printf("%5s%d\n", s1, x);
        System.out.printf("%10s%d\n", s1, x);
        System.out.printf("%15s%d\n", s1, x);
        System.out.println();
        System.out.printf("%15s%01d\n", s1, x);
        System.out.printf("%15s%02d\n", s1, x);
        System.out.printf("%15s%03d\n", s1, x);
    }
}