/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
  public static void main (String[]args)
  {
    for (int i = 1; i <= 10; i++)
      {
	if (i ==5 || i==6 ) 
	  continue ; // with this statement it wil skip the value of 5,6 in output
	  //used to skip the iteration
	  System.out.println (i);
      }
  }
}


