import java.util.Scanner;
public class Main{
    public static void main (String[]args) {
        Scanner s= new Scanner(System.in);
        System.out.print("Enter 1st Value : ");
        int a= s.nextInt();
        System.out.print("Enter 2nd Value : ");
        int b= s.nextInt();
        
        int add= a+b;
        int sub= a-b;
        int dif;
        if (a>=b) {
            dif= a-b; //Difference
        }
        else {
            dif=b-a;
        }
        
        int mul=a*b;
        double div=a>b ? (double)a/b:(double)b/a; // Ternary Operator
        /* output of the value is in decimal before
        defineing variable and beore the formula 
        (double)a/b  (double)b/a */
        int rem= a%b; // Remainder
        
        Double power =Math.pow(a,b); // Use Double because of lossy conversion
        
        System.out.println("Sum of Two values : "+ add);
        System.out.println("Subtraction of Two values : "+ sub);
        System.out.println("Difference of Two values : "+ dif);
        System.out.println("Multiple of Two values : "+ mul);
        System.out.println("Division of Two values : "+ div);
        System.out.println("Remainder of Two values : "+ rem);
        System.out.println("Base to the Power b is : "+ power);
  }
}



