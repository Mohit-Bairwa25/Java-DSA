class  Student{
    String name;
    int age;
    public void printInfo() {
        System.out.println(this.name);
        System.out.println(this.age);
    }

//Prameterise Constructor    
    Student(String name,int age){
        this.name=name;
        this.age=age;
    }
}
public class Main {
    public static void main (String args [] ){
        Student s1=new Student("shradha",14);
        
        s1.printInfo();
    }
}
/* Destructor works automatically in Java
 where Garbage Collector deletes Useless object*/  




