import java.io.*;
import java.util.*;

class Student{
    private String name;
    private String id;
    private String email;

    public String getName() {
        return name;
    }
    public void setId(String id) {
        this.id = id;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void anothermethod() { }  
//        System.out.println("......"+"\n"+"......"+"\n"+"some more methods"+"\n"+"......");

    // ......
    // ......
    // some more methods
    // ......
}

public class Main {

    public static void main(String[] args) throws Exception{
        Class student = Student.class;
        Method [] methods = student.getDeclaredMethods();
       
        ArrayList<String> methodNames = new ArrayList();
        for (Method method : methods) {
            methodNames.add(method.getName());
        }
        
        Collections.sort(methodNames);
        for (String name: methodNames) {
            System.out.println(name);
        }
    }
}