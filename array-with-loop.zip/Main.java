import java.util.Scanner;
public class Main{
  public static void main (String[]args){
    
    
    Scanner sc =new Scanner (System.in);
    System.out.print("Enter the Size of Array : ");
    int n=sc.nextInt();
    System.out.print("Enter the " +n+" Values : ");
    int [] arr = new int [n];
    for(int i=0;i<n;i++){
        arr[i]=sc.nextInt();
    }
// Pre Declaration of the Values
// Whatever the Enter value may be 
// It will Print Pre Determined value
    arr [3]=69;
    for(int i=0;i<5;i++){
        System.out.println ("Entered Values are :" + arr [i]);
    }
  }
}

