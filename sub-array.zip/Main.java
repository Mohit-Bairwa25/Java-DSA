/*  A subarray of an n-element array is an array composed from a
contiguous block of the original array's elements. For example,
if array=[1,2,3] then the subarrays are [1] ,[2] ,[3] ,[1,2] ,
[2,3] and[1,2,3] . Something like  would not be a subarray as
it's not a contiguous subsection of the original array.

Given an array n of integers, find and print its number of
negative subarrays on a new line.

*/

import java.io.*;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int n=sc.nextInt();
        int[] a = new int[n];
        for(int i=0;i<n;i++)
        a[i]=sc.nextInt();
        
        
        int count=0;
        int sum;
        for(int i=0;i<n;i++) {
        sum=0;
        for(int j=0;j<n;j++) {
            if(j>=i) {
                sum += a[j];
            }
            if(sum<0) {
                count++;
            }
        }
    }
    System.out.println(count);
    }
}