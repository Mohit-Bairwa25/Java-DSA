import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    System.out.print ("Starting of the Program : ");
    Scanner s= new Scanner(System.in);
    int a = s.nextInt();
    if (a > 50) // Never use semi Colen in if ,else ;
      {
	System.out.println ("If Statement is True"); 
	//This line will be printed if input value satisfy if condition
      }
      else
      {
         System.out.println ("If Statement is False"); 
      }
    System.out.println ("Ending of the Program");
  }
}



