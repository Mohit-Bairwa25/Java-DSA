import java.util.*;		//  Here * it will put all the libraries of util 
import java.lang.*;
import java.io.*;
public class Main
{
  public static void main (String[]args) throws java.lang.Exception
  {
    Scanner s = new Scanner (System.in);
      System.out.println ("Enter a Value : ");
    int a = s.nextInt ();
    int b = s.nextInt ();
    int c = s.nextInt ();
      System.out.println ("Entered Value is : " + a);
      System.out.println ("Entered Value is : " + b);
      System.out.println ("Entered Value is : " + c);
// Another method of displaying it
      System.out.print ("Entered Value is : " + a + "\n" + b + "\n" + c);	
/* + operator should be at right position
 \n should be used within Double Quotes
while using \n operator the 1st & Last value should be ignored
the values in between should use + operator both sides +a+ +b+ ""*/
  }
}


