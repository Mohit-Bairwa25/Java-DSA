/*When you declare an integer with a leading zero, such as 01111, it is treated
as an octal integer literal in Java. Here’s what’s going on:

Octal Integer Literal:
An integer literal that starts with a zero (0) is interpreted as an octal (base 8)
number.
In octal notation, each digit represents a power of 8.
For example, 0110 corresponds to the decimal value: (8^2 + 8^1 = 72).
*/
public class Main
{
	public static void main(String[] args) {
	    int a=011;
		System.out.println(a);
	}
}
