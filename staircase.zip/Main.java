import java.util.*;		// n=4
//        spaces   hashes
//Line 1     3   +   1   =4
//Line 2     2   +   2   =4
//Line 3     1   +   3   =4
//Line 4     0   +   4   =4
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int hashes=1;
    int spaces=n-1;
    
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<spaces;j++)
        {
            System.out.print(" ");
        }
        for(int j=0;j<hashes;j++)
        {
         System.out.print ("#");   
        }
        spaces=spaces-1;
        hashes=hashes+1;
        System.out.println();
    }
    
  }
}
