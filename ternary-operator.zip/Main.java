import java.util.*;
public class Main {
    public static void main (String[]args) {
        Scanner s = new Scanner(System.in);
        int a = s.nextInt();
        int b = s.nextInt();
        int max;
        max = a>b ? a:b; /* Ternary Operator
        max = a>b ? a:b;
        max = Condition ? Case 1: Case 2
        If the Condition is ture it will Execute Case 1
        other it will Execute Case 2
        just like if else statement */ 
        System.out.println("The Greater Value is : " + max);
    }
}


