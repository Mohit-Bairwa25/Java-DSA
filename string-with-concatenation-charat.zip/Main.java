import java.util.*;
 public class Main{
	public static void main(String[] args) {
        // Concatenation
        String firstName ="Tony";
        String lastName="Stark";
        String fullName=firstName+" "+lastName;
		System.out.println(fullName);
		System.out.println(fullName.length());
		
		//charAt
		for(int i=0;i<fullName.length();i++){
            System.out.println(fullName.charAt(i));
		}
		
		for(int i=0;i<fullName.length();i++){
            System.out.print(fullName.charAt(i));
		}
	}
 }

