interface Animal{
    int eyes=2;
// Now this will Remain Same for All Classes
    public void walk();
// In interface methods are public by default
    // Animal(){
        
    // }
// interface does not have constructor
}
interface Herbivore{
    /* interface can have multiple inheritance
    2 base class 1 derive class*/ 
}
    
}

class Horse implements Animal,Herbivore{
    public void walk(){
        System.out.println("Walks on 4 Legs");
    }
}

public class Main{
	public static void main(String[] args) {
		Horse horse=new Horse();
		horse.walk();
	}
}