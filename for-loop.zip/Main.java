/*  
    Gernral idea
    For Loop is used when we know Terminating Condition
    While Loop is use when we Don't Terminating Condition
    Do While Loop Execute one time Without Checking Condition

*/
public class Main
{
  public static void main (String[]args)
  {
    for(int i=1;i<=5;i++) //Initialisation,Condition & Updation
    {
      System.out.println (i+" Hello World"); //Task
    }

  }
}

