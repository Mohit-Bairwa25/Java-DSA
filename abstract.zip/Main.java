/* Abstract
Data hiding is the process of protecting members of class from
unintended changes whereas, abstraction is hiding the implementation
details and showing only important/ useful parts to the user.
*/

abstract class Animal {
    abstract void walk();
    // abstract method does not have a body {}

    Animal() {
        System.out.println("You are Creating a new Animal");
    }

    public void eat() {
        System.out.println("Animal eats");
    }
}

class Horse extends Animal {
    Horse() {
        System.out.println("You are Creating a new Horse");
    }
    public void walk() {
        System.out.println("Walks on 4 Legs");
    }

}

class Chicken extends Animal {
    public void walk(){
        System.out.println("Walks on 2 Legs");
    }
}

public class Main {
	public static void main(String[] args) {
		Horse horse =new Horse ();
		horse.walk();
		horse.eat();
        // 		Animal animal= new Animal();
        // 		animal.walk();
        
        // This Abstract class will show run time error
	}
}

