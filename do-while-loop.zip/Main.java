/* In Loops only in Do While loop We have to put a Semi Colen ;
   After While
*/
public class Main
{
  public static void main (String[]args)
  {
  int i = 1;
    do       //Initialisation
    {
      System.out.println (i + " Hello World"); // Task
      i++;       // Update Statement 
    }while(i<=5);  // Condition 
  }
}


