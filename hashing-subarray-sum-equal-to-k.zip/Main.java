/* Subarray sum equal to K
    arr = {} K=3 return numbers of such subarrays
    ans = 2 (1,2) (3)
    
    Approach
    arr = {10,2,-2,-20,10} k= -10
    sub(i,j) = sub(j) - sub(i-1)
    k = sub(j) - sub(i-1)
*/
import java.util.*;

public class Main {
    public static void main(String args []) {
        int arr[] = {10,2,-2,-20,10}; //ans=3
        int k =-10;
        HashMap<Integer, Integer> map = new HashMap<>();
        
        map.put(0,1);
        int ans=0;
        int sum=0;
        for(int j=0; j<arr.length; j++) {
            sum+= arr[j];
            
            if(map.containsKey(sum-k)) {
                ans+=map.get(sum-k);
            }
            
            if(map.containsKey(sum)) {
                map.put(sum, map.get(sum)+1);
            } else {
                map.put(sum,1);
            }
        }
        
        System.out.println(ans);
    }
}