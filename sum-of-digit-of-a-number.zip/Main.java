import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    Scanner s = new Scanner (System.in);
    int a = s.nextInt ();
    int b = 0;
    while (a > 0)
      {
	int c = a % 10;
	  b = b + c;		// b += c
	  a = a / 10;
	  
      }
    System.out.println (b);
/* System.out.println cannot acces variables inside the loop
until the they are Declared outside of the loop
So  System.out.println (c) will not work;*/
  }
}
