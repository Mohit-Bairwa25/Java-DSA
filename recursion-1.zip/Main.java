public class Main{
    // Print Number From One to Five
    public static void printNumb(int n){
        if(n==0){    //Base
            return;
        }
        System.out.println(n);
        printNumb(n-1); // Calling Self (Recursion)
    }
	public static void main(String[] args) {
	    int n=5;
		printNumb(n); //n=5 Recursion
	}
}



