import java.util.*;
import java.util.regex.*;
import java.io.*;
public class Main {
    public static void main(String ar[]) throws Exception {
// parseInt is used to pass Integer value as a String        
        
        int rno= Integer.parseInt("9");
        System.out.println("Your Reg.No is : "+ rno);
        
    }
}
