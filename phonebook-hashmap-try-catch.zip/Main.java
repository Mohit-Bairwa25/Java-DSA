import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        scanner.nextLine(); // To Clear the Buffer Case \n
        
        Map<String, Integer> map = new HashMap<>(n);
        
        for(int i = 0; i < n; i ++) {
            String name = scanner.nextLine();
            int contact = scanner.nextInt();
            scanner.nextLine();  // To Clear the Buffer Case \n
            map.put(name, contact);
        }
        
        // finding
        while(scanner.hasNext()) {
            String toFind = scanner.nextLine();
            try {
                int contact = map.get(toFind);
                System.out.println(toFind + "=" + contact);
            }
            catch (Exception e) {
                System.out.println("Not found");
            }
        }
    }
}