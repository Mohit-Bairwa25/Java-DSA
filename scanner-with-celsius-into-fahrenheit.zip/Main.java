import java.util.*;		//  Here * it will put all the libraries of util 
import java.lang.*;
import java.io.*;
public class Main
{
  public static void main (String[]args) throws java.lang.Exception
  {
    Scanner s = new Scanner(System.in);
    System.out.println("Enter Value in Celsius : ");
    int c = s.nextInt(); // Check for new
    int f=c*(9/5)+32;
    System.out.println("Value in Fahrenheit is : \n" + f);
  }
}
