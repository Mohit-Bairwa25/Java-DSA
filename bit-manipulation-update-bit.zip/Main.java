import java.util.*;
public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in) ;
        int oper = sc.nextInt( );
        // oper=1 : set oper=0 : clear
        int n = 5; //0101 --> 0111 --> dec 7
        int pos = 1;
        
        int bitMask = 1<<pos;
        //0001<<1  0010
        if (oper == 1) {
            //set
            int newNumber = bitMask | n;
            // bitMask = 0010 (1 shifted left by 1 position)
            //0010 | 0101
            System.out.println(newNumber);
            // newNumber = 0111 (bitwise OR operation)
            
        }
        else {
            //clear
            int newBitMask = ~(bitMask) ;
            //0010 ~ 1101
            // newBitMask = 1101 (bitwise negation of bitMask)
            int newNumber = newBitMask & n;
            //1101 & 0101
            // newNumber = 0101 (bitwise AND operation)
            System.out.println(newNumber);
            // Output: 5
        }
        
	}
}


