/*  Articulation Point
    A vertex in an undirected connected graph is an articulation point
    (or cut vertex) if removing it (and edges through it) disconnects
    the graph.

    1---0---3
    |  /    |
    | /     |
    2       4
    
    Tarjan's Algorithm
    Ancestor: a node A that was discovered before curr node in DFS,
    is the ancestor of curr.
*/

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    static class Edge {
        int src;
        int dest;

        public Edge(int s, int d) {
            this.src = s;
            this.dest = d;
        }
    }

    public static void createGraph(ArrayList<Edge>[] graph) {
        graph[0] = new ArrayList<>(Arrays.asList(new Edge(0, 1), new Edge(0, 2), new Edge(0, 3)));
        graph[1] = new ArrayList<>(Arrays.asList(new Edge(1, 0), new Edge(1, 2)));
        graph[2] = new ArrayList<>(Arrays.asList(new Edge(2, 0), new Edge(2, 1)));
        graph[3] = new ArrayList<>(Arrays.asList(new Edge(3, 0), new Edge(3, 4)));
        graph[4] = new ArrayList<>(Arrays.asList(new Edge(4, 3)));
    }

    public static void dfs(ArrayList<Edge>[] graph, int curr, int par, int[] dt, int[] low, boolean[] vis, int time, boolean[] ap) {
        vis[curr] = true;
        dt[curr] = low[curr] = ++time;
        int children = 0;
        ap[curr] = false; // Initialize ap[curr] as false

        for (Edge e : graph[curr]) {
            int neigh = e.dest;
            if (neigh == par) {
                continue;
            } else if (vis[neigh]) {
                low[curr] = Math.min(low[curr], dt[neigh]);
            } else {
                children++; // Increment children before the recursive call
                dfs(graph, neigh, curr, dt, low, vis, time, ap);
                low[curr] = Math.min(low[curr], low[neigh]);

                // Check if it is an articulation point
                if (dt[curr] <= low[neigh]) {
                    ap[curr] = true;
                }
            }
        }

        // Root node is an articulation point if it has more than one child
        if (par == -1 && children > 1) {
            ap[curr] = true;
        }
    }

    public static void getAP(ArrayList<Edge>[] graph, int V) {
        int[] dt = new int[V];
        int[] low = new int[V];
        boolean[] vis = new boolean[V];
        boolean[] ap = new boolean[V];
        int time = 0;

        for (int i = 0; i < V; i++) {
            if (!vis[i]) {
                dfs(graph, i, -1, dt, low, vis, time, ap);
                // Reset arrays after each connected component traversal
                Arrays.fill(dt, 0);
                Arrays.fill(low, 0);
                Arrays.fill(vis, false);
                Arrays.fill(ap, false);
            }
        }

        System.out.println("Articulation Points:");
        for (int i = 0; i < V; i++) {
            System.out.println("Node " + i + " is an articulation point: " + ap[i]);
        }
    }

    public static void main(String[] args) {
        int V = 5;
        ArrayList<Edge>[] graph = new ArrayList[V];
        createGraph(graph);
        getAP(graph, V);
    }
}