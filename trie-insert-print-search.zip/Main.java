/* TRIE Data Structure aka prefix,digitalsearch, Retrievel tree
    
    TRIE is a tree with n numbers of nodes 
    or we can say n array tree
    
    words[] = "the","a","there","their","any"
    
    Search Time Complexity = O(L)
    where L is the Length of the Word
    which is very fast than binary tree
    
    1.Used in fast Search
    2.Root is Empty
    
                  Root
                /     \
               t       a
             /          \
            h            n
          /               \
         e                 y
       /  \
      r    i
    /       \
   e         r
   
   From a to Z Size of Chrachter - 26
   All Valid Java Charachetr a to z, A to z,@!#$%^.... - 256
   
   
  

*/
public class Main {
    static class Node {
        Node[] children;
        boolean eow;

        public Node() {
            children = new Node[26]; // a to z
            for (int i = 0; i < 26; i++) {
                children[i] = null;
            }
            eow = false;
        }
    }

    static Node root = new Node();

    // Insertion
    public static void insert(String word) {
        Node curr = root;
        for (int i = 0; i < word.length(); i++) { // O(L)
            int idx = word.charAt(i) - 'a';
            if (curr.children[idx] == null) {
                // add new node
                curr.children[idx] = new Node();
            }
            curr = curr.children[idx];
        }
        curr.eow = true; // mark the end of the word
    }
    
    // Print the Trie structure
    public static void printTrie(Node node, String prefix) {
        if (node == null) {
            return;
        }
        
        if (node.eow) {
            System.out.println(prefix);
        }
        
        for (int i = 0; i < 26; i++) {
            if (node.children[i] != null) {
                printTrie(node.children[i], prefix + (char) (i + 'a'));
            }
        }
    }

    
    //Search
    public static boolean search (String key) {
        for(int i=0; i<key.length(); i++) {
            int idx = key.charAt(i)-'a';
            Node node = root.children[idx];
            
            if(root.children[idx] == null) {
                return false;
            }
            root = root.children[idx];
        }
        
        return true;
    }

    public static void main(String[] args) {
        String words[] = {"the", "a", "there", "their", "any"};
        for (int i = 0; i < words.length; i++) {
            insert(words[i]);
        }
        
        printTrie(root, "");
        
        System.out.println();
        System.out.println(search("their"));
        System.out.println(search("thor"));
        System.out.println(search("an"));
    }
}