public class Main {  
    public static void main(String args[]) {  
        System.out.println("Left Shift Operator");
        System.out.println("1010" + " << 2 = " + Integer.toBinaryString(Integer.parseInt("1010", 2) << 2)); // 1010 << 2 = 101000 = 40  
        System.out.println("1010" + " << 3 = " + Integer.toBinaryString(Integer.parseInt("1010", 2) << 3)); // 1010 << 3 = 1010000 = 80  
        System.out.println("10100" + " << 2 = " + Integer.toBinaryString(Integer.parseInt("10100", 2) << 2)); // 10100 << 2 = 1010000 = 80  
        System.out.println("1111" + " << 4 = " + Integer.toBinaryString(Integer.parseInt("1111", 2) << 4)); // 1111 << 4 = 11110000 = 240 
        
        System.out.println("\nRight Shift Operator");
        System.out.println("1010" + " >> 2 = " + Integer.toBinaryString(Integer.parseInt("1010", 2) >> 2)); // 1010 >> 2 = 10 = 2  
        System.out.println("10100" + " >> 2 = " + Integer.toBinaryString(Integer.parseInt("10100", 2) >> 2)); // 10100 >> 2 = 101 = 5  
        System.out.println("10100" + " >> 3 = " + Integer.toBinaryString(Integer.parseInt("10100", 2) >> 3)); // 10100 >> 3 = 10 = 2  
        
        System.out.println("\nFor positive number, >> and >>> work the same");  
        System.out.println("10100" + " >> 2 = " + Integer.toBinaryString(Integer.parseInt("10100", 2) >> 2));  
        System.out.println("10100" + " >>> 2 = " + Integer.toBinaryString(Integer.parseInt("10100", 2) >>> 2));
        
        System.out.println("\nFor negative number, >>> changes parity bit (MSB) to 0");  
        String negativeBinary = Integer.toBinaryString(-20);
        negativeBinary = negativeBinary.substring(negativeBinary.length() - 5); // consider only last 5 bits
        System.out.println("-10100" + " >> 2 = " + Integer.toBinaryString(Integer.parseInt(negativeBinary, 2) >> 2));  
        System.out.println("-10100" + " >>> 2 = " + Integer.toBinaryString(Integer.parseInt(negativeBinary, 2) >>> 2)); 
    }
}  
