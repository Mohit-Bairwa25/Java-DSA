import java.util.*;
import java.text.*;
import java.time.*;
// NOTE HERE GMT IS NOT INDIA 5:30
public class Main{
	public static void main(String[] args) {
        System.out.println(System.currentTimeMillis());
// Milli Seconds Passed From 1 January 1970
        System.out.println(System.currentTimeMillis()/1000/3600/24/365);
// 52 years is Passed From 1 January 1970

        LocalDate d = LocalDate.now();
        System.out.println(d);
        
        LocalTime t= LocalTime.now();
        System.out.println(t);
        
        LocalDateTime dt = LocalDateTime.now();
        System.out.println(dt);
        
        Date D = new Date();
        System.out.println(D);
        System.out.println(D.getSeconds());
        System.out.println(D.getMinutes());
        System.out.println(D.getHours());
        System.out.println(D.getTime());
        System.out.println(D.getDate());
        System.out.println(D.getYear());
// Years is Passed From 1 January 1900
        
        Calendar c = Calendar.getInstance();
        System.out.println(c.getCalendarType());
        System.out.println(c.getTimeZone().getID());
        System.out.println(c.getTime());
        System.out.println(c.get(Calendar.SECOND));
        System.out.println(c.get(Calendar.MINUTE));
        System.out.println(c.get(Calendar.HOUR));
        System.out.println(c.get(Calendar.HOUR_OF_DAY));
        System.out.println(c.get(Calendar.DATE));
        System.out.println(c.get(Calendar.YEAR));
// To Check a Leap Year        
        GregorianCalendar cal = new GregorianCalendar();
        System.out.println(cal.isLeapYear(2016));
        System.out.println(cal.isLeapYear(2019));
        System.out.println(cal.isLeapYear(2020));
        
        System.out.println(TimeZone.getAvailableIDs()[0]);
        System.out.println(TimeZone.getAvailableIDs()[1]);
        System.out.println(TimeZone.getAvailableIDs()[2]);
        System.out.println(TimeZone.getAvailableIDs()[5]);
        System.out.println(TimeZone.getAvailableIDs()[5+1/2]);
        
	}
}
