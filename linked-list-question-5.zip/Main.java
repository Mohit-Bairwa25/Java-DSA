/*2.Take elements(numbers in the range of 1-50) of a Linked List
as input from the user. Delete all nodes which have values 
greater than 25.*/

import java.util.Scanner;

public class Main {
    private static class ListNode {
        int val;
        ListNode next;

        ListNode(int val) {
            this.val = val;
        }
    }

    private static ListNode head; // Head of the linked list

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the elements of the linked list (1-50), separated by spaces: ");
        String[] inputs = scanner.nextLine().split(" ");
        scanner.close();

        // Create the linked list
        head = new ListNode(Integer.parseInt(inputs[0]));
        ListNode current = head;
        for (int i = 1; i < inputs.length; i++) {
            int value = Integer.parseInt(inputs[i]);
            if (value >= 1 && value <= 50) {
                current.next = new ListNode(value);
                current = current.next;
            }
        }

        // Delete nodes with values greater than 25
        head = deleteNodes(head, 25);

        // Print the modified linked list
        printList(head);
    }

    private static ListNode deleteNodes(ListNode head, int maxValue) {
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        ListNode prev = dummy;
        ListNode current = head;

        while (current != null) {
            if (current.val > maxValue) {
                prev.next = current.next;
            } else {
                prev = current;
            }
            current = current.next;
        }

        return dummy.next;
    }

    private static void printList(ListNode head) {
        ListNode current = head;
        System.out.print("Linked List: ");
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
        System.out.println();
    }
}