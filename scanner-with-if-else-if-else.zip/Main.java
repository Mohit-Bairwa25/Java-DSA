import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    System.out.println ("Starting of the Program");
    Scanner s = new Scanner (System.in);
    System.out.print("Enter a Value : ");
    int a = s.nextInt ();
    if (a<100)
      {
	System.out.println ("A i Smaller than 100");
	//This line will be printed if input value satisfy if condition
      }
    else if(a>100)
    {
      System.out.println ("A is Greater than 100");
    }
    else
    {
      System.out.println ("The Value of A is 100");
    }
    System.out.println ("Ending of the Program");
  }
}
