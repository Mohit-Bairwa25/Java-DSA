import java.util.*;
public class Main {
	public static void main(String[] args) {
		int n = 5; //0101
        int pos = 2;
        int bitMask = 1<<pos;
        //0001<<2   0100
        int notBitMask = ~(bitMask);
        //1011
        
        // Get Bit
        if( (bitMask & n) == 0) {
            //0100 AND 0101
            System.out.println("Bit was Zero");
        } 
        else {
            System.out.println("Bit was One") ;
            //0100
            // On position 2 the bit is one 
            
        }
        
        //Set Bit
        int newNumber1 =bitMask | n;
        //0100 OR 0101
        System.out.println(newNumber1);
        //0101
        
        //Clear Bit
        int newNumber2 = notBitMask & n;
        //1011 &0101
        System.out.println(newNumber2);
        //0001
	}
}


