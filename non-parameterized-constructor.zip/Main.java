class  Student{
    String name;
    int age;
    public void printInfo() {
        System.out.println(this.name);
        System.out.println(this.age);
    }

// Non-Prameterise Constructor    
    Student(){
        System.out.println("Constructor Called");
    }
}
// Java khud Se By Default Non-Prameterise Constructor Bana
// Deta Hai
public class Main {
    public static void main (String args [] ){
        Student s1=new Student();
        s1.name="shradha";
        s1.age=24;
        
        s1.printInfo();
    }
}



