public class Main
{
  public static void main (String[]args)
  {
    int []a={1,2,5,62,12};
    for(int x:a)
    {
     System.out.println (x);   
    }
    
  }
}
