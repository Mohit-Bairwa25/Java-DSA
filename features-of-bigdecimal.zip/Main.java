/**
            Features of BigDecimal
1. Scaling and Rounding modes
2. No Overloaded operators
3. Use compareTo()to compare BigDecimals not equals()
4. BigDecimals are immutable


**/

import java.math.*;
public class Main
{
	public static void main(String[] args) {
		//1.Scaling and Rounding modes
        BigDecimal bigDecimal0 = new BigDecimal(23.12);
        System.out.println("" + bigDecimal0.toString());
        // System.out.println("" + bigDecimal0.setScale(1).toString());
        
        BigDecimal bigDecimall = new BigDecimal("23.12");
        System.out.println("" + bigDecimall.toString());
        System.out.println("" + bigDecimall.setScale(1,RoundingMode.HALF_UP).toString());
        
        // In most of the cases conventional logic is to have a scale of 2
        //(2 digits after the decimal) and rounding up if the digit after the scale is >= 5
        
        BigDecimal bigDecimal2 = new BigDecimal("23.1256");
        System.out.println("bigDecimal2 " + bigDecimal2.setScale(2, RoundingMode. HALF_UP) .toString());
        BigDecimal bigDecimal3 = new BigDecimal("23.1236");
        System.out.println("bigDecimal3 " + bigDecimal3.setScale(2, RoundingMode.HALF_UP) .toString());
        BigDecimal bigDecimal4 = new BigDecimal("-15.567");
        System.out.println("bigDecimal4 " + bigDecimal4.setScale(2, RoundingMode.HALF_UP) .toString());
        
        //2.No Overloaded operators
        BigDecimal bigDecimal5 = new BigDecimal("15.567");
        BigDecimal result = BigDecimal.valueOf(68).multiply(bigDecimal5);
        System.out.println("result " + result.toString()) ;
        
        //3.Use compareTo() to compare BigDecimals not equals()
        BigDecimal bd1 = new BigDecimal("2.00");
        BigDecimal bd2 = new BigDecimal("2.0");
        System.out.println("bdl equals bd2 - " + bd1.equals(bd2));
        
        BigDecimal bd3 = new BigDecimal("2.00");
        BigDecimal bd4 = new BigDecimal("2.0");
        System.out.println("bd3 compareTo bd4- " + bd3.compareTo(bd4));
        
        //4.BigDecimals are immutable
        
	}
}

