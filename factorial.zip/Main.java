import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc= new Scanner (System.in);
    int n=sc.nextInt();
    long a=1;
    for(int i=1;i<=n;i++) // Note i=1;
    {
      a=a*i;
    }
    System.out.println(a);
  }
}
