/*Write a program to find if a number is a power of 2 or not
*/

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();
        if (isPowerOfTwo(num)) {
            System.out.println(num + " is a power of 2");
        } else {
            System.out.println(num + " is not a power of 2");
        }
        scanner.close();
    }

    public static boolean isPowerOfTwo(int n) {
        // A number is a power of 2 if it has only one bit set
        // Using bitwise AND with n-1 should result in 0 for power of 2 numbers
        return n != 0 && (n & (n - 1)) == 0;
        /*
        1. n != 0: This condition checks if the number n is not equal to 0.
        This is important because 0 is not considered a power of 2.
        
        2. (n & (n - 1)) == 0: This is the main logic for determining whether
        n is a power of 2 or not.
        n - 1 decrements n by 1.
        (n & (n - 1)) performs a bitwise AND operation between n and n - 1.
        If n is a power of 2, it will have only one bit set, and subtracting
        1 from it will result in all the bits to the right of the set bit
        becoming 1 (and the set bit becoming 0).
        For example, 8 in binary is 1000, and 8 - 1 is 7,
        which is 0111. When you perform a bitwise AND
        operation between 1000 and 0111, you get 0000, which is 0
        
        1000 (8 in binary)
        & 0111 (7 in binary)
        -----------
        0000
        
        1010 (10 in binary)
        & 1001 (9 in binary)
        -----------
        1000
        
        */
    }
}
