public class Main {
	public static void main(String[] args) {
        // ParseInt Method of Integer class
        String str1 = "123";
       int number1 = Integer.parseInt(str1);
       System.out.println(number1);
      
      //  To String Method
      int number2 = 1234;
      String str2 = Integer.toString(number2);
      System.out.println(str2);
      System.out.println(str2.length());

	}
}



