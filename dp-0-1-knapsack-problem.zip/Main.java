public class Main {
    public static int knapsack(int W, int[] wt, int[] val) {
        int n = val.length;
        int[][] dp = new int[n+1][W+1];

        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= W; j++) {
                if (wt[i-1] > j) {
                    dp[i][j] = dp[i-1][j];
                } else {
                    dp[i][j] = Math.max(dp[i-1][j], dp[i-1][j-wt[i-1]] + val[i-1]);
                }
            }
        }

        return dp[n][W];
    }

    public static void main(String[] args) {
        int W = 10;
        int[] wt = {1, 3, 4, 6};
        int[] val = {20, 30, 10, 50};
        System.out.println("Maximum profit: " + knapsack(W, wt, val));
    }
}