import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
      /*
      12345
      1234
      123
      12
      1*/
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int o=n-1;
    // outer loop
    for(int i=1;i<=n;i++)
    {
        // inner loop spaces
        for(int j=1;j<=n-i+1;j++)
     System.out.print(j);   
    
    System.out.println ();
    }
  }
}
