import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
public class Main {
    public static void main(String[] args) {
        /* Here we did not describe the terminating condition of 
        foor while loop */
              Scanner sc = new Scanner(System.in);
               int c =1;
               while(sc.hasNext()){
               String s = sc.nextLine();
               System.out.println(c+" "+s);
               c++;
            }
        }
   }