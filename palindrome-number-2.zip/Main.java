import java.util.*;
public class Main{
//123
//321  //3*10+2;
// We have to multiply it by 10
//otherwise 3+2=5

    public static void main (String[]args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int copy=n;
        int reverse=0;
        while(n!=0){
            int digit=n%10;
            n=n/10;
            reverse=reverse*10+digit;
        }
        if(reverse==copy){
            System.out.println ("True");
        }
        else
        System.out.println ("False");
      
   }
}

