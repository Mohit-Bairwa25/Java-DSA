public class Main
{
  public static void main (String[]args)
  {
    int i = 1;
    for (;;)		//Initialisation,Condition & Updation
//For loop Cannot be left blank you have to put 2 semicolen in it
     {
	  if (i > 50)
	  break;
	  System.out.println ("2x" + i + "=" + i * 2);	//Task
      i++;
          
     }

  }
}
