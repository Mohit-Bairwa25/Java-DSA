//3.Write a program to count the number of 1’s in a binary representation of the number.
public class Main {
    public static int countOnes(int n) {
        int count = 0;
        
        // Loop through each bit of the number
        while (n != 0) {
            // Use bitwise AND to check if the least significant bit is 1
            // If it's 1, increment the count
            count += n & 1;
            
            // Right shift the number by 1 to check the next bit
            n >>= 1;
        }
        
        return count;
    }
    
    public static void main(String[] args) {
        int number = 23; // Example number
        // Print the binary representation of the number
        System.out.println("Binary representation of " + number + ": " + Integer.toBinaryString(number));
        // Count the number of 1's in the binary representation
        int count = countOnes(number);
        // Print the count
        System.out.println("Number of 1's: " + count);
    }
}
/*
1. Initialization: Initially, count is set to 0.

2. Loop through each bit: We start a loop that continues until the
number n becomes 0.

3 Checking the least significant bit: In each iteration, we use
bitwise AND (&) operation with 1 to check if the least significant
bit of n is 1.

.If the least significant bit is 1, then n & 1 will be 1, and we
increment the count.
If the least significant bit is 0, then n & 1 will be 0, and no
increment occurs.
Example:

For n = 23 (binary: 10111), the least significant bit is 1, so n & 1
is 1, and we increment count by 1.
After incrementing count, count becomes 1.
Right shift the number: We right shift the number n by 1 bit to move
to the next bit position.

Repeat: Steps 3 and 4 are repeated until n becomes 0.

Return the count: After the loop ends, we return the final count
of 1's in the binary representation of the original number.

For the example number 23, the count of 1's in its binary
representation (10111) is 4. Therefore, the function will return 4
*/
