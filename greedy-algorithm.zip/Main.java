import java.util.Arrays;
/* The Greedy algorithm is a problem-solving strategy that
makes the optimal choice at each step with the hope of
finding the global optimum. In other words, it selects
the best option at the current stage without worrying
about the consequences of the decision at a later stage. */
public class Main {
    public static void main(String[] args) {
        int amount = 93;
        int[] coins = {1, 5, 10, 25};
        int[] minCoins = minCoins(amount, coins);
        System.out.println("Minimum number of coins required: " + Arrays.stream(minCoins).sum());
        System.out.println("Coin breakdown: ");
        for (int i = minCoins.length - 1; i >= 0; i--) {
            if (minCoins[i] > 0) {
                System.out.println(coins[i] + " cents: " + minCoins[i]);
            }
        }
    }

    public static int[] minCoins(int amount, int[] coins) {
        int[] result = new int[coins.length];
        Arrays.sort(coins); // Sort coins in ascending order

        for (int i = coins.length - 1; i >= 0; i--) {
            int coinValue = coins[i];
            result[i] = amount / coinValue;
            amount %= coinValue;
        }

        return result;
    }
}