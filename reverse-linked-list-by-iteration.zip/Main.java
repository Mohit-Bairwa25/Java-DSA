/*Reverse a Linked List by Iterative Meathod using
Time Complexity :O(n)
Space Complexity :O(1)
It means no extra memory is used in this program
*/

import java.util.*;

class Main {

    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    private static Node head;

    public static void printList(LinkedList<Integer> list) {
        for (Integer element : list) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    public static void reverseIterate(LinkedList<Integer> list) {
        if (list.isEmpty()) {
            return;
        }

        // Create a linked list from the given LinkedList
        Node curr = null;
        for (int element : list) {
            Node newNode = new Node(element);
            newNode.next = curr;
            curr = newNode;
        }
        head = curr;

        Node prevNode = null;
        curr = head;
        while (curr != null) {
            Node nextNode = curr.next;
            curr.next = prevNode;
            prevNode = curr;
            curr = nextNode;
        }
        head = prevNode;

        // Update the LinkedList with the reversed linked list
        list.clear();
        Node node = head;
        while (node != null) {
            list.addLast(node.data);
            node = node.next;
        }
    }

    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        list.addLast(2);
        list.addLast(3);
        list.addLast(4);
        list.addLast(5);

        printList(list);
        reverseIterate(list);
        printList(list);
    }
}