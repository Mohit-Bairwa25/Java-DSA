import java.util.*;
public class Main {
	public static void main(String[] args) {
        int arr[]={7,8,3,1,2};
        String arr1[]= {"M", "A", "G", "Pa", "Pb", "B", "O"};
        
        Arrays.sort(arr);
        Arrays.sort(arr1);
        
        for(int i=0;i<arr.length;i++) {
            System.out.println(arr[i]+" ");
        }
		
        for(int i=0;i<arr1.length;i++) {
            System.out.println(arr1[i]+" ");
        }	
	}
}