/*
Regular Expression is a sequence of characters that constructs a search pattern.When you search for data
in a text,you can use this search pattern to describe what you are looking for.

        Start of the line               3 to 15 characters long
                        |               |
                        ^[a-z8-9 _-]{3,15}$
                    letters,  | | |       End of the line
                        numbers,| hyphens
                            underscores, 
                            
The Java Regex is an API which is used to define a pattern for searching or manipulating Strings.It is widely used
to define the constraint on Strings such as password and email validation.

                MATCHER CLASS
boolean matches()           Tests whether the given regular expression matches or not
boolean find()              Used to find the next expression that matches the pattern
boolean find(int start)     Searches the next expression from the given start number
String group()              Used to return the matched sequence
int start()                 Returns the starting index
int end()                   Returns the ending index
int groupCount()            Returns the total number of the matched sequence

                                PATTERN CLASS
Static Pattern compile(String regex)        It compiles the given regex and returns the instance of a pattern
Matcher matcher(charSequence input)         Used to create a matcher that matches the given input with the pattern
Static boolean matches(String regex)        It works as a combination of compile and matcher methods.
String split[]                              Used to split the given String around matches of a given pattern
String pattern()                            Helps to return the regex pattern
Int end()                                   Returns the ending index

        REGEX CHARACTER CLASS
[abc]               a,b or c (A Simple class)
[^abc]              Any class except a, b or c (negation)
[a-zA-Z]            A through Z or a trough z inclusive(Range)
[a-d[m-p]]          a through d or m through p(union)
[a-z &&[def]]       d,e,or f(Intersection)
[a-z &&[^bc]]       A through z except b or c(Subtraction)
[a-z &&[^m-p]]      A through z and not m through p(Subtraction)

    REGEX QUANTIFIERS
X? X            occurs once or not at all
X+ X            occurs more than one times
X* X            occurs zero or more times
X{n} X          occurs n times only
X{n,} X         occurs n or more times only
X{y,z} X        occurs at least y times but less than z times

    REGEX METACHARACTERS
.       It can be any character
d       Represents any digits
D       Represents any non digit
s       Represents any white space
S       Non white space character
w       It can be a word character
W       It can be a word character
b       Represents a word boundary
B       It represents a non word boundary

*/
import java.util.regex.*;
public class Main {
    public static void main (String[] args) {
        
        System.out.println("PATTERN & MATCHER CLASS");
        Pattern pattern = Pattern.compile(".kx.");
        Matcher matcher = pattern.matcher("AxxB");
        System.out.println("String matches the given Regex : "+ matcher.matches());
        
        System.out.println(Pattern.matches("[xyz]", "wbcd"));// false (not x or y or 2)
        System.out.println(Pattern.matches("[xyz]", "x"));// true (among x or y or 2)
        System.out.println(Pattern.matches("[xyz]", "xxyyyyy "));// false (x and y comes more than once
        
        System.out.println("? quantifier ....");
        System.out.println(Pattern.matches("[ayz]?", "a"));// true (a or y or z comes one time)
        System.out.println(Pattern.matches("[ayz]?", "aaa"));// false (a comes more than one time)
        System.out.println(Pattern.matches("[ayz]?", "ayyyyzz"));// false (a y and z comes more than one time)
        System.out.println(Pattern.matches("[ayz]?", "amnta"));// false (a comes more than one time)
        System.out.println(Pattern.matches("[ayz]?", "ayz"));// true (a or y or z must come one time)
        System.out.println("+ quantifier ....");
        System.out.println(Pattern.matches("[ayz]+", "a"));// true (a or y or z once or more times)
        System.out.println(Pattern.matches("[ayz]+", "aaa"));// true (a comes more than one time)
        System.out.println(Pattern.matches("[ayz]+", "aayyyzz"));// true (a or y or z comes more than once)
        System.out.println(Pattern.matches("[ayz]+", "aammta"));// false (m and t are not matching pattern)
        System.out.println(" quantifier ....");
        System.out.println(Pattern.matches("[ayz]*", "ayyyza"));// true (a or y or z may come zero or more times)
        
        System.out.println("metacharacters d ....");// d means digit I
        System.out.println(Pattern.matches("d", "abc"));// false (non-digit)
        System.out.println(Pattern.matches("d", "1"));// true (digit and comes once)
        System.out.println(Pattern.matches("d", "4443"));// false (digit but comes more than once)
        System.out.println(Pattern.matches("d", "323abc"));// false (digit and char)
        System.out.println("metacharacters D ....");// D means non-digit
        System.out.println(Pattern.matches("D", "abc"));// false (non-digit but comes more than once)
        System.out.println(Pattern.matches("D", "1"));// false (digit)
        System.out.println(Pattern.matches("D", "4443"));// false (digit)
        System.out.println(Pattern.matches("D", "323abc"));// false (digit and char)
        System.out.println(Pattern.matches("D", "m"));// true (non-digit and comes once)
        
        System.out.println("metacharacters D with quantifier ....");
        System.out.println(Pattern.matches("D ", "abc"));// true (non-digit and may come 0 or more times)
    }
}



