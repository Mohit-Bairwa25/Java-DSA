/* Access Modifiers
Deafult:- Apne package me usse sasri ki saari cheeze
acess kar payengi bas koi dusra package usse acess nahi
kar payega
*/

class Account {
    public String name;
    protected String email;
    private String password;
    
    // getters
    public String getPassword(){
        return this.password;
    }
    
    // setters
    public void setPassword(String pass){
        this.password=pass;
    }
    
// Dusre Package me Sub classes & Current Package me koi nahi
// Acess kar sakta hai
}

public class Main{
	public static void main(String[] args) {
        /* The Above Statement is by default public NOT 
        private , protected because Execution Start from main
        class & it should be accesable*/
		
		Account account1= new Account();
		account1.name="Apna College";
		account1.email="apnacollege@gmail.com";
		account1.setPassword("abcd");
		System.out.println(account1.getPassword());
		  
	}
}


