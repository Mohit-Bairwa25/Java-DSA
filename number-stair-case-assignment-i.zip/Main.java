// Nesting :- Placement of one or more objects within another object
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of rows: ");
        int n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            // Print spaces for each row
            for (int j = 0; j < n - i - 1; j++) {
                System.out.print("\t");
            }

            // Print numbers for each row
            for (int j = 0; j <= i; j++) {
                System.out.print((i * (i + 1) / 2 + j + 1) + "\t\t");
            }
            System.out.println();
        }

        scanner.close();
    }
}
