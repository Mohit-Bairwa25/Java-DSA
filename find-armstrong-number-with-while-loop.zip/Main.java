/*Given a number N, you need to check whether the given number is Armstrong number or not. Now what is Armstrong
number let us see below:
A number is said to be Armstrong if it is equal to sum Of the Of its digits.
Input
A single integer N,
Output
You need to return 1 if the given number N is an Armstrong number otherwise O*/
import java.util.*;
import java.io.*;
// 123 123/10=>12 acoording to java
// 1  2  3
public class Main{
  public static void main (String[]args){
    Scanner sc= new Scanner(System.in);
    int n=sc.nextInt();
    int sum=0;
    int copy=n;
    // n=123,12,1,,0
    while(n!=0){
        // For loop is used when you are sure of the terminating condition
        // While loop is used when you are NOT sure of the terminating condition
        int digit = n%10; //3,2,1
        n=n/10;  // n=12,1,0
        sum=sum+digit*digit*digit; // sum=27,35,36
    }
    if (sum==copy){
        System.out.println(1);
    }
    else
    System.out.println(0);
  }
}