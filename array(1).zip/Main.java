import java.util.*;
public class Main{
    public static void main (String[]args){
      
        int [] arr = new int [5];
        // int [] arr = new int [43,45,63,64,35];
        arr [0]= 45;
        arr [1]= 43;
        arr [2]= 54;
        arr [3]= 23;
        arr [4]= 02;
        System.out.println (arr    );
        //This will print a grabage Value
        System.out.println (arr [0]);
        System.out.println (arr [1]);
        System.out.println (arr [2]);
        System.out.println (arr [3]);
        System.out.println (arr [4]);
        
     // [] can also be writen behind the array name   
        int brr[]=new int[3];
        brr[0]=11;
        brr[1]=22;
        brr[2]=33;
        for(int i=0;i<=2;i++){
            System.out.println(brr[i]);
        }
        
        int crr[]={44,55,66,77};
        for(int i=0;i<=2;i++){
            System.out.println(crr[i]);
        }
        
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int drr[]=new int[n];
        for(int i=0;i<=2;i++){
            System.out.println(drr[i]);
            //In Java Arrays are Automatically Initiliased by Null Values
        }
        
        int m=sc.nextInt();
        int err[]=new int[m];
        
        //Arrays used 0 bsed indexing so always use lessthan<
        // NOT lessthan<=
        for(int i=0;i<m;i++){
            err[i]=sc.nextInt();
        }
        
        for(int i=0;i<err.length;i++){
            // arrayName.Length have stored size of array
            System.out.println(err[i]);
        }
    }
}


