/*
        1
       / \
      2   3
     / \   \
    4   5   6
*/

import java.util.LinkedList;
import java.util.Queue;

class Node {
    int data;
    Node left, right;

    Node(int data) {
        this.data = data;
        left = null;
        right = null;
    }
}

public class Main {
    static Node root;

    public static void main(String[] args) {
        // Build the binary tree from the given input
        root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.right.right = new Node(6);

        // Ask the user for the level (N)
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Enter the level (N) to calculate the sum: ");
        int level = scanner.nextInt();

        // Calculate and print the sum of nodes at the given level
        int sum = sumAtLevel(root, level);
        System.out.println("Sum of nodes at level " + level + " is: " + sum);
    }

    // Function to calculate the sum of nodes at a given level using a queue
    static int sumAtLevel(Node root, int level) {
        if (root == null)
            return 0;

        Queue<Node> queue = new LinkedList<>();
        queue.offer(root);
        int sum = 0;
        int currentLevel = 1; // Start from level 1

        while (!queue.isEmpty()) {
            int size = queue.size();

            if (currentLevel == level) {
                for (int i = 0; i < size; i++) {
                    Node node = queue.poll();
                    sum += node.data;
                }
            } else {
                for (int i = 0; i < size; i++) {
                    Node node = queue.poll();
                    if (node.left != null)
                        queue.offer(node.left);
                    if (node.right != null)
                        queue.offer(node.right);
                }
            }

            currentLevel++;
        }

        return sum;
    }
}