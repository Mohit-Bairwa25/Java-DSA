import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    Scanner s= new Scanner(System.in);
    int year= s.nextInt();
/*  == This means Comparing two data types
    = This means assinging a value to integer*/
// 4 5 8 100 104 200 400   
    if(year%4==0) // multiple of 4
    {
     // 4 8 100 104 200 400
        if(year%100==0)  //multiple of 4 & 100
        {
         // 100 200 400  
            if(year%400==0) // multiple of 4 100 400
            {
                System.out.println("1"); // 400
            }
            else // multiple of 4 & 100 NOT 400
            System.out.println("0"); // 100
        }
        else
        System.out.println("1"); // 4 8 104
    }
    else
    System.out.println ("0"); // 5
  }
}
