/*This Program let you check the input value is a Integer Value or Not
with the help of Boolean*/
import java.util.*; // j of java is small
public class Main
{
  public static void main (String[]args)
  {
    Scanner s= new Scanner(System.in);
    Boolean b= s.hasNextInt(); // has,Next,Int are Case Sensitive
    System.out.println (b);
  }
}
/*
=  Assingment Operator
== Equal to Operator
=! Not Equal to
Some Basic Operators
<  >  >=   <=
These Operator use to check Boolean Conditions*/

