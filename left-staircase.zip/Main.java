// Nesting :- Placement of one or more objects within another object
import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
   System.out.print("Enter a Value :");
   Scanner sc = new Scanner(System.in);
   int n=sc.nextInt();
   for(int i=1; i<=n ; i++) //Order of Sign should be <= NOT =<
   {
     for(int j=1; j<=i;j++)
     {
        System.out.print("*"); 
     }
     System.out.println(); 
   }
  }
}