import java.math.*;
public class Main {
    
    private static BigInteger factorial(int number){
        BigInteger fact = BigInteger.ONE;
        for (int i= 2; i<= number; i ++){
            fact= fact.multiply(BigInteger.valueOf(i));
        }
        return fact;
    }
    
    public static void main(String[] args) {
        int num = 25;
        BigInteger factorial = factorial(num);
        System.out.println("Factorail of "+num+" is:"+factorial);
        
        //1.No Overloaded operators
        BigInteger bigInteger = new BigInteger("56") ;
        BigInteger result = BigInteger.valueOf(45) .multiply(bigInteger) ;
        System.out.println("result is -" + result) ;
        
        // 2. BigInteger class is immutable
        
        //3.Don't use any decimal number
        // BigInteger bigInteger2 = new BigInteger("12.00");
        
        //4.For comparing you can use equals or compare To method
        
        BigInteger i1 = new BigInteger("21");
        BigInteger i2 = new BigInteger("12");
        System.out.println("i1 compare To i2 : " + i1.compareTo(i2));
        
    }
}
