public class Main {
  int x = 5;
  int y = 6;

    public static void main(String[] args) {
        
        int x = 4;
        System.out.println(x);
      
      
        Main myObj = new Main();
        System.out.println(myObj.x);
        
        myObj.y=7;
        System.out.println(myObj.y);
        
    }
}
