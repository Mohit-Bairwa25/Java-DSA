/* Check if a Linked List is a palindrome
    Time complexity - O(n)
    Space complexity - O(1)
No Extra Space is used to solve this question
*/

public class Main {
   private static class ListNode {
       int val;
       ListNode next;
       
       ListNode(int val) {
           this.val = val;
       }
   }

   public static boolean isPalindrome(ListNode head) {
       if (head == null || head.next == null) {
           return true; // Empty list or single node is considered a palindrome
       }
       
       // Step 1: Find the middle node using the turtle/rabbit pointers technique
       ListNode turtle = head;
       ListNode rabbit = head;
       while (rabbit.next != null && rabbit.next.next != null) {
           turtle = turtle.next;
           rabbit = rabbit.next.next;
       }
       
       // Step 2: Reverse the second half of the linked list
       ListNode prevNode = null;
       ListNode secondHalfStart = turtle.next;
       turtle.next = null; // Separate the first and second halves
       
       while (secondHalfStart != null) {
           ListNode nextNode = secondHalfStart.next;
           secondHalfStart.next = prevNode;
           prevNode = secondHalfStart;
           secondHalfStart = nextNode;
       }
       
       // Step 3: Compare the first and reversed second halves
       ListNode firstHalfStart = head;
       ListNode secondHalfReversed = prevNode;
       while (secondHalfReversed != null) {
           if (firstHalfStart.val != secondHalfReversed.val) {
               return false; // Not a palindrome
           }
           firstHalfStart = firstHalfStart.next;
           secondHalfReversed = secondHalfReversed.next;
       }
       
       return true; // Is a palindrome
   }

   public static void main(String[] args) {
       // Example usage
       ListNode head = new ListNode(1);
       head.next = new ListNode(2);
       head.next.next = new ListNode(3);
       head.next.next.next = new ListNode(2);
       head.next.next.next.next = new ListNode(1);
       
       System.out.println(isPalindrome(head)); // Output: true
   }
}