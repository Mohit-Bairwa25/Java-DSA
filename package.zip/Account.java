package bank.*;

class Account{
    public String name;
    public class Bank{
    
    }
}