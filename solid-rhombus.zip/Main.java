public class Main
{
  public static void main (String[]args)
  {
      /*
                *****
               *****
              *****
             *****
            *****
      */
      int n=5;
      // Outer Loop
      for(int i=0;i<=n;i++)
      {
          // Spaces
          for(int j=1;j<=n-i;j++)
          {
            System.out.print (" "); 
          }
          
          // Stars
          for(int j=1;j<=n;j++)
          {
            System.out.print ("*"); 
          }
          System.out.println ();
      }
    
  }
}
