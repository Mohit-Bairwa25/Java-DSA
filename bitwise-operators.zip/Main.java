import java.util.*;

public class Main {
    public static void main(String[] args) {
        /*The 0b prefix in Java denotes that the following
        digits represent a binary literal.*/
        int a = 0b0101; // Binary representation of 5
        int b = 0b0110; // Binary representation of 6
        
        System.out.print("Binary AND : ");
        System.out.println(Integer.toBinaryString(a & b));
        
        System.out.print("Binary OR : ");
        System.out.println(Integer.toBinaryString(a | b));
        
        System.out.print("Binary XOR : ");
        System.out.println(Integer.toBinaryString(a ^ b));
        
        System.out.print("Binary One's Complement for a: ");
        System.out.println(Integer.toBinaryString(~a & 0b1111)); 
        // Apply bitwise AND to get the last 4 bits
        
        System.out.print("Binary One's Complement for b: ");
        System.out.println(Integer.toBinaryString(~b & 0b1111)); 
        // Apply bitwise AND to get the last 4 bits
        
        int shiftedLeftA = a << (b & 0b11);
        // Ensure that number of shifts is within the range of 0 to 3
        System.out.print("Binary Left Shift a by b: ");
        System.out.println(Integer.toBinaryString(shiftedLeftA & 0b1111)); // Apply bitwise AND to get the last 4 bits
        
        int shiftedLeftB = b << (a & 0b11); 
        // Ensure that number of shifts is within the range of 0 to 3
        System.out.print("Binary Left Shift b by a: ");
        System.out.println(Integer.toBinaryString(shiftedLeftB & 0b1111)); // Apply bitwise AND to get the last 4 bits
        
        int shiftedRightA = a >>> (b & 0b11);
        // Ensure that number of shifts is within the range of 0 to 3
        System.out.print("Binary Right Shift a by b: ");
        System.out.println(Integer.toBinaryString(shiftedRightA & 0b11)); // Apply bitwise AND to get the last 2 bits
        
        int shiftedRightB = b >>> (a & 0b11); 
        // Ensure that number of shifts is within the range of 0 to 3
        System.out.print("Binary Right Shift b by a: ");
        System.out.println(Integer.toBinaryString(shiftedRightB & 0b11)); // Apply bitwise AND to get the last 2 bits
    }
}
