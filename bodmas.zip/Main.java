public class Main{
    public static void main(String[] args){
        
        // Java Does not follow BODMAS Rule
        // Execution Priority
        // */%  < +-
        int a=10;
        int b=5;
        int ans=a*b/a-b; // Wrong way
        int anv=(a*b)/(a-b); //Right Way
        System.out.println(ans);
        System.out.println(anv);

    }
}

