public class Main
{
	public static void main(String[] args) {
		int a=4;
		int b=5;
		System.out.println("a = "+a +"\t"+ "b = "+b);
		// Swapping 1st Method
		int temp =a; //temp=4
		a=b;         // a=5
		b=temp;      // b=4
		System.out.println("a = "+a +"\t"+ "b = "+b);
		// Swapping 2nd Method (Saves Memory no Extra Variable Needed)
		a=a+b;     // a=7
		b=a-b;     // b=4
		a=a-b;     // a=5
		System.out.println("a = "+a +"\t"+ "b = "+b);
	}
}
