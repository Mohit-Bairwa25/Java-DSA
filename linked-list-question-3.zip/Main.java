/* Detecting Loop in a Linked List.
& Removing the Loop
Time complexity - O(n)
Space complexity - O(1)
*/

public class Main {
    private static class ListNode {
        int val;
        ListNode next;
        
        ListNode(int val) {
            this.val = val;
        }
    }

    public static boolean hasCycle(ListNode head) {
        if (head == null || head.next == null) {
            return false; // Empty list or single node, no cycle
        }
        
        ListNode slow = head;
        ListNode fast = head;
        
        // Find the meeting point of slow and fast pointers
        boolean hasCycle = false;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
                hasCycle = true;
                break;
            }
        }
        
        // If there is no loop, return false
        if (!hasCycle) {
            return false;
        }
        
        // Reset slow to head to find the start of the loop
        slow = head;

        // Move slow and fast pointers one node at a time until they meet
        while (slow != fast) {
            slow = slow.next;
            fast = fast.next;
        }
        
        // Print the linked list with the repeating part
        ListNode current = slow;
        System.out.print("Linked List with Loop: ");
        do {
            System.out.print(current.val + " ");
            current = current.next;
        } while (current != slow);
        System.out.println();
        
        // Remove the loop
        while (fast.next != slow) {
            fast = fast.next;
        }
        fast.next = null; // Break the loop
        
        return true; // Cycle detected
    }

    public static void printList(ListNode head) {
        System.out.print("Linked List without Loop: ");
        ListNode current = head;
        while (current != null) {
            System.out.print(current.val + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        // Example usage
        ListNode head = new ListNode(1);
        head.next = new ListNode(2);
        head.next.next = new ListNode(3);
        head.next.next.next = new ListNode(4);
        head.next.next.next.next = head.next; // Creating a cycle
        
        boolean hasLoop = hasCycle(head);
        System.out.println("Has Loop? " + hasLoop);
        
        if (hasLoop) {
            printList(head); // Print the linked list without the loop
        }
    }
}