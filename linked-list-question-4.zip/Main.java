/*1.Make a Linked List & add the following elements to
it : (1, 5, 7, 3 , 8, 2, 3). Search for the number 7 
& display its index.*/

public class Main {
    private static class ListNode {
        int val;
        ListNode next;
        
        ListNode(int val) {
            this.val = val;
        }
    }

    private static ListNode head; // Head of the linked list

    public static void main(String[] args) {
        // Create the linked list
        head = new ListNode(1);
        ListNode current = head;
        current.next = new ListNode(5);
        current = current.next;
        current.next = new ListNode(7);
        current = current.next;
        current.next = new ListNode(3);
        current = current.next;
        current.next = new ListNode(8);
        current = current.next;
        current.next = new ListNode(2);
        current = current.next;
        current.next = new ListNode(3);

        // Search for the number 7
        int index = searchElement(head, 7);
        if (index != -1) {
            System.out.println("Element 7 found at index: " + index);
        } else {
            System.out.println("Element 7 not found in the linked list.");
        }
    }

    private static int searchElement(ListNode head, int target) {
        ListNode current = head;
        int index = 0;
        
        while (current != null) {
            if (current.val == target) {
                return index;
            }
            current = current.next;
            index++;
        }

        return -1; // Element not found
    }
}