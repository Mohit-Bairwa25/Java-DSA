import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of rows: ");
        int n = scanner.nextInt();

        for (int i = 1; i <= n; i++) {
            // Print spaces for each row
            for (int j = 1; j <= n - i; j++) {
                System.out.print("\t");
            }

            // Print numbers for each row
            for (int j = 1; j <= i; j++) {
                System.out.print(i + "\t\t");
            }
            System.out.println();
        }

        scanner.close();
    }
}
