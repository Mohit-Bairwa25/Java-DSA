import java.util.*;
public class Main{
  public static void main (String[]args){
    /*
       1
       23
       456
       78910
       1112131415
     */
    Scanner sc = new Scanner (System.in);
    int n = sc.nextInt ();
    int o = 1;
    // outer loop
    for (int i = 1; i <= n; i++){
	// inner loop spaces
	    for (int j = 1; j <= i; j++){
	        System.out.print (o);
	        o++;
	    }
        System.out.println ();
    }
  }
}

