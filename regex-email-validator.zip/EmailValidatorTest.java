import org.testng.Assert;
/**
* Email validator Testing
"
*/
public class EmailValidatorTest {
    private EmailValidator emailValidator;
    
    @BeforeClass
    public void initData() {
        emailValidator = new EmailValidator();
    }
    
    @DataProvider
    public Object[][] ValidEmailProvider() {
        return new Object[][] { { new String[] { "edureka@yahoo.com",
        "edureka123@gmail.a", "edureka123@.com", "edureka123@.com.com",
        ".edureka@edureka.com", "edureka()*@gmail.com", "edureka@%*.com",
        "edureka..2019@gmail.com", "edureka.@gmail.com",
        "edureka@edureka@gmail.com", "edureka@gmail.com.la" } } };
    }
    
    @DataProvider
    public Object[][] InvalidEmailProvider() {
        return new Object[][] { { new String[] { "edureka", "edureka@.com.my",
            "edureka123@gmail.a", "edureka123@.com", "edureka123@.com.com",
            ".edureka@edureka.com", "edureka()*@gmail.com", "edureka@%*.com",
            "edureka..2019@gmail.com", "edureka.@gmail.com",
            "edureka@edureka@gmail.com", "edureka@gmail.com.la" } } };
    }
        
    @Test(dataProvider = "ValidEmailProvider*")
    public void ValidEmailTest (String [] Email) {
        
        for (String temp: Email) {
            boolean valid = emailValidator.validate (temp);
            System.out.println ("Email is valid : " + temp + " " + valid );
            Assert.assertEquals (valid , true);
        }
    }
    
    @Test(dataProvider = "InvalidEmailProvider", dependsOnMethods = "ValidEmailTest")
    public void InValidEmailTest(String[] Email) {
        
        for (String temp : Email) {
            boolean valid = emailValidator.validate(temp);
            System.out.println("Email is valid : " + temp +" " + valid);
            Assert.assertEquals(valid, false);
        }
    }
}