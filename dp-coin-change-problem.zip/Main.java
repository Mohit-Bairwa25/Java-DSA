/* Dyanmic Programing
                            18(7,5,1)
                              /  |  \
                            /    |   \
                          /     |     \
                11(7,5,1)   13(7,5,1)   17(7,5,1)
                 /   |  \     / |   \     /  |  \
                /    |   \   /  |    \   /  |    \
              4     6    10 6   8   12  10  12    16
              

Dynamic programming is a technique used to solve complex problems by breaking
them down into simpler sub-problems and solving those sub-problems only once.
It involves storing the solutions to these sub-problems so that they can be
reused later, instead of re-computing them every time they are needed.

*/
import java.util.Arrays;

public class Main {
    static int minCoins(int n, int[] a, int[] dp) {
        if (n == 0) return 0;
        if (dp[n] != -1) return dp[n]; // Check if the subproblem is already solved

        int ans = Integer.MAX_VALUE;

        for (int i = 0; i < a.length; i++) {
            if (n - a[i] >= 0) {
                int subAns = minCoins(n - a[i], a, dp); // Recursive call
                if (subAns != Integer.MAX_VALUE && subAns + 1 < ans) {
                    ans = subAns + 1;
                }
            }
        }

        dp[n] = ans; // Store the result for the subproblem
        return ans;
    }

    public static void main(String[] args) {
        int n = 18;
        int[] a = {7, 5, 1};
        int[] dp = new int[n + 1];
        Arrays.fill(dp, -1); // Initialize dp array with -1
        dp[0] = 0; // Base case for 0 coins

        int ans = minCoins(n, a, dp);
        System.out.println(ans);
        for(int x: dp) {
            System.out.print(x+ " ");
        }
    }
}