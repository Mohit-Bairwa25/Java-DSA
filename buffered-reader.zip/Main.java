/*Accepting User Input
in Java there are broadly two ways to take input from the user. The first one is to
use Buffered Reader Class and the second is way is to use Scanner Class.
Taking Input using Buffered Reader Class
Buffered Reader is a class which is found in "io" package. So, in order to use
Buffered Reader class we import "io" package in our program.
There is a function "readLine()" which is used to read one line of input. Let's Learn
how to take input through a program.

Scanner:
It can parse the user input and read an int, short, byte,float,long
and double apart from String.
Buffered Reader: can only read String in Java.
Scanner : Buffer size is 1KB
Buffered Reader : Buffer size is 8KB*/

import java.io.*;
class Main {
    public static void main(String args[])throws IOException {
        int a,b,c;
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter First Number : ");
        a=Integer.parseInt(br.readLine());
        System.out.print("Enter Second Number : ");
        b=Integer.parseInt(br.readLine());
        c=a+b;
        System.out.println("Addition = "+c);
    }
}