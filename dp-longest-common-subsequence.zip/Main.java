public class Main {
    public static void main(String[] args) {
        String s1 = "ABCAB";
        String s2 = "AECB";
        System.out.println("Length of Longest Common Subsequence: " + lcs(s1, s2));
        System.out.print("Longest Common Subsequence: ");
        printLCS(s1, s2);
    }

    public static int lcs(String s1, String s2) {
        int m = s1.length();
        int n = s2.length();

        // Create a 2D dp table to store the lengths of LCS of substrings
        int[][] dp = new int[m + 1][n + 1];

        // Fill the dp table in a bottom-up manner
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }

        return dp[m][n];
    }

    public static void printLCS(String s1, String s2) {
        int m = s1.length();
        int n = s2.length();
        int lcsLength = lcs(s1, s2);

        // Create a character array to store the LCS
        char[] lcs = new char[lcsLength];
        int index = lcsLength - 1;

        // Create a 2D dp table to store the lengths of LCS of substrings
        int[][] dp = new int[m + 1][n + 1];

        // Fill the dp table in a bottom-up manner
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }

        // Traverse the dp table to construct the LCS
        int i = m, j = n;
        while (i > 0 && j > 0) {
            if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                lcs[index] = s1.charAt(i - 1);
                index--;
                i--;
                j--;
            } else if (dp[i - 1][j] > dp[i][j - 1]) {
                i--;
            } else {
                j--;
            }
        }

        // Print the LCS
        for (char c : lcs) {
            System.out.print(c);
        }
        System.out.println();
    }
}