import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Main{
	public static void main(String[] args) {
	    double price = 123.4567;
        System.out.printf("The total price is %f\n", price);
// Default behaviour of %f is of 6 zeros (000000)
        System.out.printf("1 The total price is %.2f\n", price);
        System.out.printf("2 The total price is %.4f\n", price);
        System.out.printf("3 The total price is $%.4f\n", price);
        System.out.printf("4 The total price is $%,.4f\n", price);
        
        System.out.println("5 The total price is $" + price);
        
        DecimalFormat df = new DecimalFormat("$0.00");
        System.out.println("6 The total price is " + df.format(price));
        
        DecimalFormat dt = new DecimalFormat("$0,000.00");
        System.out.println("7 The total price is "+ dt.format(price));
        
        double cost =93.4567;
        DecimalFormat dg = new DecimalFormat("$0,000.00");
        System.out.println("The total price is "+ dg.format(cost));
        
        DecimalFormat dl = new DecimalFormat("$#,#00.00");
        System.out.println("The total price is "+ dl.format(cost));
	}
}
