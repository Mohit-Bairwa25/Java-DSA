import java.util.Scanner;

public class Main {
    // Function to calculate power
    static double power(double x, int n) {
        double result = 1.0;
        
        // Handling negative exponent
        if (n < 0) {
            x = 1 / x;
            n = -n;
        }
        
        // Calculating power using loop
        for (int i = 0; i < n; i++) {
            result *= x;
        }
        
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking input from the user
        System.out.print("Enter the base number (x): ");
        double x = scanner.nextDouble();

        System.out.print("Enter the exponent (n): ");
        int n = scanner.nextInt();

        // Calculating and printing the result
        double result = power(x, n);
        System.out.println(x + " raised to the power of " + n + " is: " + result);

        scanner.close();
    }
}
