/*Given a number N, you need to check whether the given number is Armstrong number or not. Now what is Armstrong
number let us see below:
A number is said to be Armstrong if it is equal to sum Of the Of its digits.
Input
A single integer N,
Output
You need to return 1 if the given number N is an Armstrong number otherwise O*/
import java.util.*;
import java.io.*;
// 123 123/10=>12 acoording to java
// 1  2  3
public class Main{
  public static void main (String[]args){
    Scanner sc= new Scanner(System.in);
    int n=sc.nextInt();
    int sum=0;
    int copy=n;
    // n=123,12,1,,0
    for(int i=n;i!=0;i=i/10){
        int digit=i%10;
        sum=sum+digit*digit*digit;
    }
    if (sum==copy){
        System.out.println(1);
    }
    else
    System.out.println(0);
  }
}