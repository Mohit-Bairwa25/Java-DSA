public class Main
{
	public static void main(String[] args) {
	    
	    //Case 1
	    String sentence="My name is Tony";
	    // Substring(Beginning index, Ending index)
	    //it takes Ending index by default
	    String name1=sentence.substring(11);
		System.out.println(name1);
		
		//Case 2
	    String name2=sentence.substring(0,1);
		System.out.println(name2);
		
		//Case 3
	    String name3=sentence.substring(8,sentence.length());
		System.out.println(name3);
		
		//String are Immutable
		//Means they cannot be changed,deleted or moditfy
	}
}

