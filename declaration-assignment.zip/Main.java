/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
  public static void main (String[]args)
  {

    int a = 13;               // Declaration & Assingment Together
      System.out.println (a);
    int Num;                  // Declaration  
    Num = 14;                 // Assingment
      System.out.println (Num);
      int uday =15;          // uday has store value 15
                             // when uday is used again to store value it will store new value
      uday=16;              // uday has store value 16, old value 15 is replaced with 16
      System.out.println (uday);
      
  }
}
