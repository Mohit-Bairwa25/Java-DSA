/* Polymorphism= Ek kaam Ko alag Alag Tarike Se Karna
2 Types = Function Oveloading, Function OverRiding
                |
                v
Compile Type Polymorphism
*/
class  Student{
    String name;
    int age;
/* Function Oveloading :- All names are Same
but there must be a Differntiating Factor
Like Diffent Return Type OR
It should have Diffent Parameters

*/
    public void printInfo(String name) {
       System.out.println(name);
    }
    
    public void printInfo(int age) {
       System.out.println(age);
    }
    
    public void printInfo(String name,int age) {
       System.out.println(name+" "+age);
    }

}

public class Main {
    public static void main (String args [] ){
        Student s1 = new Student();
        s1.name="shradha";
        s1.age=24;
        // Here it automatically checks which function to call       
        s1.printInfo(s1.name,s1.age);
        
        
        s1.printInfo(s1.age);
    }
} 

