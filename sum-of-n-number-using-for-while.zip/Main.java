import java.util.*;
import java.io.*;
public class Main
{
  public static void main (String[]args)
  {
    Scanner s= new Scanner(System.in);
    int n=s.nextInt();
    int sum=0;

    for(int i=1;i<=n;i++)
    {sum=sum+i;} // OR sum+=1 also works
    System.out.println(sum);
    /*
    
    while(n>0)
    {
        sum=sum+n;
        n--;
    }
    System.out.println(sum);
    */
  }
}

