import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // You can test your maximumSumRectangle method here
        int R = 4, C = 4;
        int[][] matrix = {
            {1, 2, -1, -4},
            {-8, -3, 4, 2},
            {3, 8, 10, 1},
            {-4, -1, 1, 7}
        };
        Solution sol = new Solution();
        int maxSum = sol.maximumSumRectangle(R, C, matrix);
        System.out.println("Maximum sum of 3x3 submatrix: " + maxSum);
    }

    static class Solution {
        public int maximumSumRectangle(int R, int C, int[][] matrix) {
            int maxSum = Integer.MIN_VALUE;

            for (int cStart = 0; cStart < C; cStart++) {
                int[] sum = new int[R];

                for (int cEnd = cStart; cEnd < C; cEnd++) {
                    Arrays.fill(sum, 0); // Reset the sum array for each new cEnd

                    for (int row = 0; row < R; row++) {
                        for (int col = cStart; col <= cEnd; col++) {
                            sum[row] += matrix[row][col];
                        }

                        int curMaxSum = kadans(sum);
                        maxSum = Math.max(maxSum, curMaxSum);
                    }
                }
            }

            return maxSum;
        }

        int kadans(int[] arr) {
            int size = arr.length;
            int max_so_far = Integer.MIN_VALUE, max_ending_here = 0;

            // Kadane's algorithm to find the maximum subarray sum
            for (int i = 0; i < size; i++) {
                // Calculate the maximum subarray sum ending at the current index
                max_ending_here = Math.max(0, max_ending_here + arr[i]);

                // Update the maximum subarray sum so far
                max_so_far = Math.max(max_so_far, max_ending_here);
            }

            return max_so_far;
        }
    }
}