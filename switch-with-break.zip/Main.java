import java.util.*;
public class Main
{
  public static void main (String[]args)
  {
    System.out.println ("How to make a Tea");
    Scanner s= new Scanner(System.in);
    int var= s.nextInt();
    switch (var)
/* break operator  break the flow of switch
it can be put after 2 or 3 cases accordingly
*/
    {
        default :System.out.println ("Entered Value is Not Defined");
        break;
         case 1 :System.out.println ("Put a cup of water in Empty Kettle");
         break;
         case 2 :System.out.println ("Turn on gas and keep Kettle on it");
         break;
         case 3 :System.out.println ("Add 2 Spoon Tea");
         break;
         case 4 :System.out.println ("Add 15gram of Crushed Ginger");
         break;
         case 5 :System.out.println ("Boil the water on Medium Flame for 4 Minutes");
         break;
         case 6 :System.out.println ("Add 2 Cup of Milk");
         break;
         case 7 :System.out.println ("Add 2 Spoon Sugar");
         break;
         case 8 :System.out.println ("Boil the water on High Flame for 10 Minutes");
         break;
         case 9 :System.out.println ("Filter the solution and Serve it");
        
    } 
    
  }
}

