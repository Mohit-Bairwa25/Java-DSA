/*
A Binary Search Tree is a node-based binary tree data
structure with the following properties:
1. The left subtree of a node contains only nodes with
keys lesser than the node’s key.
2. The right subtree of a node contains only nodes with
keys greater than the node’s key.
3. The left and right subtree each must also be a binary
search tree.
4.There are no duplicate elements in a binary search tree.
5. The element at the left child of a node is always less
than the element at the current node.
6. The left subtree of a node has all elements less than
the current node.
7. Inorder Travesal of Binary Search Tree gives a Sorted
Sequence.
*/

public class Main {
    static class Node {
        int data;
        Node left;
        Node right;
        
        Node (int data) {
            this.data=data;
        }
    }
    
    public static Node insert (Node root, int val) {
        
        if (root == null) {
            root = new Node(val);
            return root;
        }
        
        if(root.data > val) {
            // left subtree
            root.left = insert(root.left,val);
        }
        
        else {
            root.right=insert(root.right,val);
        }
        
        return root;
    }
    
    public static void inorder (Node root) {
        if (root == null) {
            return;
        }
        
        inorder ( root.left);
        System.out.print ( root.data+" ");
        inorder(root.right);
    }
    
    public static void main (String args [] ) {
        int values [] = {5, 1, 3, 4, 2, 7};
        Node root = null;
        
        for(int i=0; i<values.length;i++) {
            root =insert(root,values[i]);
        }
        
        inorder(root);
        System.out.println();
    }
}

