import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int rows, height, digits, space;

        System.out.print("Enter the height of the pattern: ");
        height = in.nextInt();

        System.out.println("\nThis the butterfly pattern:\n\n");

        for(rows = 1; rows <= height - 1; rows++) {
            System.out.print("\t");
            for(digits = 1; digits <= rows; digits++)
                System.out.print(digits);
            for(space = 1; space <= 2 * (height - rows); space++)
                System.out.print(" ");
            System.out.print('\b');
            for(digits = rows; digits >= 1; digits--)
                System.out.print(digits);
            System.out.print('\n');
        }

        for(rows = height; rows >= 1; rows--) {
            System.out.print("\t");
            for(digits = 1; digits <= rows; digits++)
                System.out.print(digits);
            for(space = 1; space <= 2 * (height - rows); space++)
                System.out.print(" ");
            System.out.print('\b');
            for(digits = rows; digits >= 1; digits--)
                System.out.print(digits);
            System.out.print('\n');
        }
    }
}