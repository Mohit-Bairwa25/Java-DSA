public class Main{
	public static void main(String[] args) {
        int sum=10;
		System.out.println(sum);
        sum=sum+10;
		System.out.println(sum);
        sum+=10;
		System.out.println(sum);
		System.out.println();
		
		int diff=30;
		System.out.println(diff);
        diff=diff-10;
		System.out.println(diff);
        diff-=10;
		System.out.println(diff);
		System.out.println();
		
		int mul=30;
		System.out.println(mul);
        mul=mul*10;
		System.out.println(mul);
        mul*=10;
		System.out.println(mul);
		System.out.println();
		
		int div=300;
		System.out.println(div);
        div=div/10;
		System.out.println(div);
        div/=10;
		System.out.println(div);
		System.out.println();
		
	}
}
