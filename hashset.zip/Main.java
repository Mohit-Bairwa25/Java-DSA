/* Insert/Add - O(1)
    Search/Contains - O(1)
    Delete/Remove - O(1)
    It Stores Only Unique Elements
    Duplicate Elements are not stored here
    It Does not store data in order
*/
import java.util.*;

public class Main {
  public static void main (String args[]) {
    //Creating
    HashSet < Integer > set = new HashSet <> ();

    //Insert
    set.add (1);
    set.add (2);
    set.add (3);
    set.add (1);		// list. add(el)

    //Search - contains

    if(set.contains (1)) {
        System.out.println ("set contains 1");
    }

    if (!set.contains (6)) {
        System.out.println ("Does not contain 6");
    }

    //Delete
    set.remove (1);
    if (!set.contains (1)) {
    	System.out.println ("Does not contain 1");
    }

    //Size
    System.out.println ("Size of set is " + set.size ());

    // Print all Elements of Set
    System.out.println (set);

    //Iterator - HashSet does not have an order
    Iterator it = set.iterator ();
    // hasNext ; next        
    while( it.hasNext() ) {
        System.out.println( it.next() );
    }
    
    //isEmpty
       if(!set.isEmpty()) {
           System.out.println("set is not empty");
       }
  }
}

