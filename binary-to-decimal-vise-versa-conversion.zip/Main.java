public class Main {
    // Function to convert a decimal number to binary
    public static String decimalToBinary(int decimal) {
        StringBuilder binary = new StringBuilder();
        
        // Edge case: if the number is 0, return "0"
        if (decimal == 0) {
            return "0";
        }
        
        while (decimal > 0) {
            int remainder = decimal % 2;
            binary.insert(0, remainder); // Insert the remainder at the beginning
            decimal /= 2;
        }
        
        return binary.toString();
    }
    
    // Function to convert a binary number to decimal
    public static int binaryToDecimal(String binary) {
        int decimal = 0;
        int power = 0;
        
        // Start from the rightmost digit
        for (int i = binary.length() - 1; i >= 0; i--) {
            int digit = binary.charAt(i) - '0'; // Convert char to int
            decimal += digit * Math.pow(2, power);
            power++;
        }
        
        return decimal;
    }
    
    public static void main(String[] args) {
        int decimalNumber = 23;
        String binaryNumber = "10111";
        
        // Convert decimal to binary
        System.out.println("Binary representation of " + decimalNumber + " is: " + decimalToBinary(decimalNumber));
        
        // Convert binary to decimal
        System.out.println("Decimal representation of " + binaryNumber + " is: " + binaryToDecimal(binaryNumber));
    }
}
/*
Converting Decimal to Binary (decimalToBinary()):
1. We start with an empty StringBuilder named binary.
2. We check if the decimal number is 0. Since it's not,
we proceed.
3. We enter a while loop where we repeatedly divide the
decimal number by 2 until it becomes 0.
4. At each step, we take the remainder of the division
(0 or 1) and prepend it to the binary StringBuilder.
This is because binary representation works from right to left.
After the loop finishes, we return the binary representation
as a string.
Example:

Decimal number: 23
Binary conversion:
23 / 2 = 11 remainder 1 (prepend '1' to binary)
11 / 2 = 5 remainder 1 (prepend '1' to binary)
5 / 2 = 2 remainder 1 (prepend '1' to binary)
2 / 2 = 1 remainder 0 (prepend '0' to binary)
1 / 2 = 0 remainder 1 (prepend '1' to binary)
Binary result: 10111

Converting Binary to Decimal (binaryToDecimal()):
1. We start with a decimal number initialized to 0 and a 
power variable initialized to 0.
2. We iterate through each digit of the binary number from right to left.
3. At each step, we calculate the decimal equivalent by 
multiplying the digit (0 or 1) with 2 raised to the power of
its position (0-based).
4. We accumulate these values to get the final decimal number.
Example:

Binary number: 10111
Decimal conversion:
1 * 2^0 = 1 (add 1 to decimal)
1 * 2^1 = 2 (add 2 to decimal)
1 * 2^2 = 4 (add 4 to decimal)
0 * 2^3 = 0 (no addition to decimal)
1 * 2^4 = 16 (add 16 to decimal)
Decimal result: 23
So, decimalToBinary(23) returns "10111", and binaryToDecimal
("10111") returns 23, as expected.

1. while (decimal > 0): This is a while loop that continues
as long as the decimal variable is greater than 0. This loop
iterates through the process of converting the decimal number
to binary.

2.int remainder = decimal % 2;: Here, we calculate the remainder
when the decimal number is divided by 2. This remainder will be
either 0 or 1, representing the binary digit.

3.binary.insert(0, remainder);: We use the insert() method of 
the StringBuilder class to insert the remainder at the beginning
of the binary StringBuilder. This effectively adds the binary 
digit (remainder) to the left side of the existing binary 
representation. Since binary representation is built from 
right to left, inserting at index 0 ensures that each new 
binary digit is added to the leftmost position.

4. decimal /= 2;: This line divides the decimal number by 2,
effectively shifting it to the right. This operation prepares
the next digit to be extracted as the remainder in the next
iteration of the loop.

So, in summary, each iteration of the loop calculates the
remainder of the current decimal number when divided by 2,
adds it to the left side of the binary StringBuilder, and 
then updates the decimal number by dividing it by 2. This
process continues until the decimal number becomes 0, at 
which point we have converted the entire decimal number to
its binary representation.
*/