public class Main
{
	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=30;
		if(a<b && b<c)
		System.out.println("Satisfy Logical AND");
		if(a>b || b>c || c>a)
		System.out.println("Satisfy Logical OR");
		if(!(a>b))
		System.out.println("Satisfy Logical NOT");
	}
}
