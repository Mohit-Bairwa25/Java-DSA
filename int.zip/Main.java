/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
  public static void main (String[]args)
  {
    System.out.println ("Welcome to AccioJob");
/* 
   we can also use byte,short,int,long according to storage prefernces
   byte<short<int<long
*/
    int a = 13;			        // Always use semicolen ; after ending a line
      System.out.println (a);
    int Num = 14;               // Here N is capital in Num so 
      System.out.println (Num); // Here it also should be capital Num NOT num
    int uday = 15;
      System.out.println (uday);
  }
}
/* Never use 0 before declaration of value
int a =13;  Correct Way
int a =013; Wrong WAy
*/


