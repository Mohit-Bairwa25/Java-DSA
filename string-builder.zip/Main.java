import java.util.*;
public class Main {
	public static void main(String[] args) {
	    //StringBuilder reduces Time Complexity
	    StringBuilder sb=new StringBuilder("Tony");
	    System.out.println(sb);
	    
	    //char at index 0
	    System.out.println(sb.charAt(0));
	    
	    //Set char at index 0
	    sb.setCharAt(0,'P');
	    System.out.println(sb);
	    
	    //Insert a char in String
	    sb.insert(0,'S');
	    System.out.println(sb);
	
    	sb.insert(4,'n');
	    System.out.println(sb);
	    
	    // Delete the char
	    sb.delete(2,5);
	    System.out.println(sb);
	    
	    // Add word in end
	    sb.append("e"); // str=str+"e"';
	    sb.append("l"); //str=str+"e";
	    sb.append("l");
	    sb.append("o");
	    sb.append("w");
	    System.out.println(sb);
	    
	    System.out.println(sb.length());
	}
}

